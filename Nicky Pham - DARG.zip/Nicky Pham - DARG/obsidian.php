<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Obsidian Mapping</title>
</head>

<body>
<style>
	#map{float:center;height:1000px;margin-left:125px;overflow:auto;}#sidebar{position:absolute;left:0px;max-height:960px;width:130px;overflow:auto;}.sb_blue button{text-align:center;cursor:arrow;background-color:#80CC99;font-family:Verdana;margin:2px;}.sb_blue button:focus{background-color:#eee;}.sb_blue button:hover{background-color:#fff;}
	
	#content {width:100%;}
	
	#sidebar {padding-left: 10px;}
	
</style>

<script type="text/javascript" src="http://maps.google.com/maps/api/js?key=AIzaSyA6Y5TlDHWdgA3Bm7gOF9nBEGQ644sjWFI&sensor=false"></script>
<div id="sidebar" class="sb_blue"></div>
<div id="map"></div>
<script>	

//map
var mapOpts = {
  mapTypeId: google.maps.MapTypeId.ROADMAP,
  scaleControl: true,
  maxZoom:8,
}
var map = new google.maps.Map(document.getElementById("map"), mapOpts);

//marker and info
var infoWindow = new google.maps.InfoWindow();
var markerBounds = new google.maps.LatLngBounds();
var markerArray = [];
 
function makeMarker(options){
  var pushPin = new google.maps.Marker({map:map});
  pushPin.setOptions(options);
  google.maps.event.addListener(pushPin, "click", function(){
    infoWindow.setOptions(options);
    infoWindow.open(map, pushPin);
    if(this.sidebarButton)this.sidebarButton.button.focus();
  });
  var idleIcon = pushPin.getIcon();
  if(options.sidebarItem){
    pushPin.sidebarButton = new SidebarItem(pushPin, options);
    pushPin.sidebarButton.addIn("sidebar");
  }
  markerBounds.extend(options.position);
  markerArray.push(pushPin);
  return pushPin;
}

google.maps.event.addListener(map, "click", function(){
  infoWindow.close();
});

//create sidebar
function SidebarItem(marker, opts){
  var tag = opts.sidebarItemType || "button";
  var row = document.createElement(tag);
  row.innerHTML = opts.sidebarItem;
  row.className = opts.sidebarItemClassName || "sidebar_item";  
  row.style.display = "block";
  row.style.width = opts.sidebarItemWidth || "100px";
  row.onclick = function(){
    google.maps.event.trigger(marker, 'click');
  }
  row.onmouseover = function(){
    google.maps.event.trigger(marker, 'mouseover');
  }
  row.onmouseout = function(){
    google.maps.event.trigger(marker, 'mouseout');
  }
  this.button = row;
}
// adds a sidebar item to a <div>
SidebarItem.prototype.addIn = function(block){
  if(block && block.nodeType == 1)this.div = block;
  else
    this.div = document.getElementById(block)
    || document.getElementById("sidebar")
    || document.getElementsByTagName("body")[0];
  this.div.appendChild(this.button);
}
// deletes a sidebar item
SidebarItem.prototype.remove = function(){
  if(!this.div) return false;
  this.div.removeChild(this.button);
  return true;
}

//marker info content
makeMarker({
  position: new google.maps.LatLng(37.82357, -107.94678),
  title: "5DL2458",
  sidebarItem: "5DL2458",
  content: "<b>Site# </b>5DL2458<br><b>FSD# </b>1<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>n/a<br><b>Description </b>middle Archaic stemmed<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Mount Wilson<br><b>County </b>Dolores<br><b>Temporal Cultural Association </b>Middle Archaic<br><b>Elevation </b>11480ft<br><b>PM </b>NM<br><b>Township </b>41N<br><b>Range </b>10W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});   
makeMarker({
  position: new google.maps.LatLng(37.81912, -107.94582),
  title: "5DL2459",
  sidebarItem: "5DL2459",
  content: "<b>Site# </b>5DL2459<br><b>FSD# </b>2<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>n/a<br><b>Description </b>isolated find, serrated point tip<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Mount Wilson<br><b>County </b>Dolores<br><b>Temporal Cultural Association </b>Middle Archaic, Uncompahgre complex, Roubideau phase<br><b>Elevation </b>11200ft<br><b>PM </b>NM<br><b>Township </b>41N<br><b>Range </b>10W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});  
makeMarker({
  position: new google.maps.LatLng(39.14107, -107.59491),
  title: "5DT919",
  sidebarItem: "5DT919",
  content: "<b>Site# </b>5DT919<br><b>FSD# </b>3<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Spruce Mountain<br><b>County </b>Delta<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>8920ft<br><b>PM </b>6th<br><b>Township </b>10S<br><b>Range </b>91W<br><b>Section </b>31<br><b>Datum </b>NAD83"
}); 
makeMarker({
  position: new google.maps.LatLng(39.14092, -107.59352),
  title: "5DT920",
  sidebarItem: "5DT920",
  content: "<b>Site# </b>5DT920<br><b>FSD# </b>4<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>n/a<br><b>Description </b>flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Spruce Mountain<br><b>County </b>Delta<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>8940ft<br><b>PM </b>6th<br><b>Township </b>10S<br><b>Range </b>91W<br><b>Section </b>31<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.78467, -107.58382),
  title: "5DT1382",
  sidebarItem: "5DT1382",
  content: "<b>Site# </b>5DT1382<br><b>FSD# </b>5<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>n/a<br><b>Description </b>flake<br><b>Geochemical Source </b>Cerro Toledo Rhy, NM<br><b>Quad Map </b>Paonia<br><b>County </b>Delta<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>7200ft<br><b>PM </b>6th<br><b>Township </b>15S<br><b>Range </b>91W<br><b>Section </b>5<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.85737, -106.57555),
  title: "5DT1742",
  sidebarItem: "5DT1742",
  content: "<b>Site# </b>5DT1742<br><b>FSD# </b>6<br><b>Artifact Type </b>Chunk<br><b>Artifact# </b>s1<br><b>Description </b>chunk<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Taylor Park Reservior<br><b>County </b>Gunnison<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9480ft<br><b>PM </b>6th<br><b>Township </b>14S<br><b>Range </b>82W<br><b>Section </b>5<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.92072, -106.60708),
  title: "5DT1746",
  sidebarItem: "5DT1746",
  content: "<b>Site# </b>5DT1746<br><b>FSD# </b>7<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>s2a<br><b>Description </b>projectile point base<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Pieplant<br><b>County </b>Gunnison<br><b>Temporal Cultural Association </b>Archaic<br><b>Elevation </b>9800ft<br><b>PM </b>6th<br><b>Township </b>13S<br><b>Range </b>83W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.83617, -106.59709),
  title: "5GN1785",
  sidebarItem: "5GN1785",
  content: "<b>Site# </b>5GN1785<br><b>FSD# </b>8<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>small flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Taylor Park Reservior<br><b>County </b>Gunnison<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9520ft<br><b>PM </b>6th<br><b>Township </b>14S<br><b>Range </b>82W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.66187, -107.07993),
  title: "5GN1809",
  sidebarItem: "5GN1809",
  content: "<b>Site# </b>5GN1809<br><b>FSD# </b>9<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>s1<br><b>Description </b>projectile point midsection<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Squirrel Creek<br><b>County </b>Gunnison<br><b>Temporal Cultural Association </b>unknown<br><b>Elevation </b>10820ft<br><b>PM </b>NM<br><b>Township </b>51N<br><b>Range </b>2W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.6862, -106.75465),
  title: "5GN4322",
  sidebarItem: "5GN4322",
  content: "<b>Site# </b>5GN4322<br><b>FSD# </b>10<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>A2<br><b>Description </b>small flake<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Almont<br><b>County </b>Gunnison<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>8680ft<br><b>PM </b>NM<br><b>Township </b>51N<br><b>Range </b>2E<br><b>Section </b>16<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.58096, -106.74301),
  title: "5GN4655",
  sidebarItem: "5GN4655",
  content: "<b>Site# </b>5GN4655<br><b>FSD# </b>11<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>A13<br><b>Description </b>interior flake<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Parlin<br><b>County </b>Gunnison<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9320ft<br><b>PM </b>NM<br><b>Township </b>50N<br><b>Range </b>2E<br><b>Section </b>22<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.21823, -107.38596),
  title: "5GN4818",
  sidebarItem: "5GN4818",
  content: "<b>Site# </b>5GN4818<br><b>FSD# </b>12<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>n/a<br><b>Description </b>small flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Sheep Mountain<br><b>County </b>Gunnison<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9600ft<br><b>PM </b>NM<br><b>Township </b>46N<br><b>Range </b>5W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.02034, -107.18105),
  title: "5HN267",
  sidebarItem: "5HN267",
  content: "<b>Site# </b>5HN267<br><b>FSD# </b>13<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s2<br><b>Description </b>small flake<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Cannibal Plateau<br><b>County </b>Hinsdale<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10360ft<br><b>PM </b>NM<br><b>Township </b>44N<br><b>Range </b>3W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.02032, -107.18196),
  title: "5HN268",
  sidebarItem: "5HN268",
  content: "<b>Site# </b>5HN268<br><b>FSD# </b>14<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>3E<br><b>Description </b>medium flake<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Cannibal Plateau<br><b>County </b>Hinsdale<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10280ft<br><b>PM </b>NM<br><b>Township </b>44N<br><b>Range </b>3W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.01879, -107.18237),
  title: "5HN269",
  sidebarItem: "5HN269",
  content: "<b>Site# </b>5HN269<br><b>FSD# </b>15<br><b>Artifact Type </b>Biface<br><b>Artifact# </b>s1<br><b>Description </b>biface fragment<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Cannibal Plateau<br><b>County </b>Hinsdale<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10280ft<br><b>PM </b>NM<br><b>Township </b>44N<br><b>Range </b>3W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.04784, -107.11122),
  title: "5HN265",
  sidebarItem: "5HN265",
  content: "<b>Site# </b>5HN265<br><b>FSD# </b>16<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>02G<br><b>Description </b>flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Mineral Mountain<br><b>County </b>Hinsdale<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9500ft<br><b>PM </b>NM<br><b>Township </b>44N<br><b>Range </b>2W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.0417, -107.09179),
  title: "5HN278",
  sidebarItem: "5HN278",
  content: "<b>Site# </b>5HN278<br><b>FSD# </b>17<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>small flake<br><b>Geochemical Source </b>Cochetopa Dome, CO<br><b>Quad Map </b>Mineral Mountain<br><b>County </b>Hinsdale<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9480ft<br><b>PM </b>NM<br><b>Township </b>44N<br><b>Range </b>2W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.09314, -107.90391),
  title: "5ME1331",
  sidebarItem: "5ME1331",
  content: "<b>Site# </b>5ME1331<br><b>FSD# </b>18<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Grand Mesa<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9800ft<br><b>PM </b>6th<br><b>Township </b>11S<br><b>Range </b>94W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.08696, -107.92793),
  title: "5ME1334",
  sidebarItem: "5ME1334",
  content: "<b>Site# </b>5ME1334<br><b>FSD# </b>19<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>possible biface fragment, definite utilized flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Grand Mesa<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10320ft<br><b>PM </b>6th<br><b>Township </b>11S<br><b>Range </b>94W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.01749, -108.08392),
  title: "5ME1533",
  sidebarItem: "5ME1533",
  content: "<b>Site# </b>5ME1533<br><b>FSD# </b>20<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>s1<br><b>Description </b>projectile point base<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Skyway<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>Late Prehistoric?<br><b>Elevation </b>10320ft<br><b>PM </b>6th<br><b>Township </b>12S<br><b>Range </b>96W<br><b>Section </b>14<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.29398, -108.38024),
  title: "6/8/15-1",  
  sidebarItem: "6/8/15-1",
  content: "<b>Site# </b>6/8/15-1<br><b>FSD# </b>21<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>n/a<br><b>Description </b>projectile point midsection<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Big Bucktail Creek<br><b>County </b>Montrose<br><b>Temporal Cultural Association </b>unknown<br><b>Elevation </b>6420ft<br><b>PM </b>NM<br><b>Township </b>47N<br><b>Range </b>14W<br><b>Section </b>26<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.01298, -108.08746),
  title: "5ME1537",
  sidebarItem: "5ME1537",
  content: "<b>Site# </b>5ME1537<br><b>FSD# </b>22<br><b>Artifact Type </b>Biface<br><b>Artifact# </b>s1<br><b>Description </b>biface base<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Skyway<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10450ft<br><b>PM </b>6th<br><b>Township </b>12S<br><b>Range </b>96W<br><b>Section </b>14<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.01212, -108.09257),
  title: "5ME1540",
  sidebarItem: "5ME1540",
  content: "<b>Site# </b>5ME1540<br><b>FSD# </b>23<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>n/a<br><b>Description </b>small flake<br><b>Geochemical Source </b>Mineral Mtns, UT<br><b>Quad Map </b>Skyway<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10420ft<br><b>PM </b>6th<br><b>Township </b>12S<br><b>Range </b>96W<br><b>Section </b>14<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.00851, -108.10681),
  title: "5ME1541",
  sidebarItem: "5ME1541",
  content: "<b>Site# </b>5ME1541<br><b>FSD# </b>24<br><b>Artifact Type </b>Biface<br><b>Artifact# </b>s1<br><b>Description </b>biface fragment<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Skyway<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10380ft<br><b>PM </b>6th<br><b>Township </b>12S<br><b>Range </b>96W<br><b>Section </b>15<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.00914, -108.11059),
  title: "5ME1542",
  sidebarItem: "5ME1542",
  content: "<b>Site# </b>5ME1542<br><b>FSD# </b>25<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s5<br><b>Description </b>small flake<br><b>Geochemical Source </b>Mineral Mtns, UT<br><b>Quad Map </b>Skyway<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10380ft<br><b>PM </b>6th<br><b>Township </b>12S<br><b>Range </b>96W<br><b>Section </b>15<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.08826, -107.90464),
  title: "5ME5034",
  sidebarItem: "5ME5034",
  content: "<b>Site# </b>5ME5034<br><b>FSD# </b>26<br><b>Artifact Type </b>Scraper<br><b>Artifact# </b>s2<br><b>Description </b>scraper<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Grand Mesa<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9840ft<br><b>PM </b>6th<br><b>Township </b>11S<br><b>Range </b>94W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.08826, -107.90464),
  title: "5ME5034",
  sidebarItem: "5ME5034",
  content: "<b>Site# </b>5ME5034<br><b>FSD# </b>27<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s7<br><b>Description </b>flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Grand Mesa<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9840ft<br><b>PM </b>6th<br><b>Township </b>11S<br><b>Range </b>94W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.08815, -107.90186),
  title: "5ME5035",
  sidebarItem: "5ME5035",
  content: "<b>Site# </b>5ME5035<br><b>FSD# </b>28<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s2<br><b>Description </b>utilized flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Grand Mesa<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9840ft<br><b>PM </b>6th<br><b>Township </b>11S<br><b>Range </b>94W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.08815, -107.90186),
  title: "5ME5035",
  sidebarItem: "5ME5035",
  content: "<b>Site# </b>5ME5035<br><b>FSD# </b>29<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s4a<br><b>Description </b>utilized flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Grand Mesa<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9840ft<br><b>PM </b>6th<br><b>Township </b>11S<br><b>Range </b>94W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.01329, -108.10338),
  title: "5ME5183",
  sidebarItem: "5ME5183",
  content: "<b>Site# </b>5ME5183<br><b>FSD# </b>30<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>flake<br><b>Geochemical Source </b>Malad, ID<br><b>Quad Map </b>Skyway<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10400ft<br><b>PM </b>6th<br><b>Township </b>12S<br><b>Range </b>96W<br><b>Section </b>15<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.00793, -108.08351),
  title: "5ME5193",
  sidebarItem: "5ME5193",
  content: "<b>Site# </b>5ME5193<br><b>FSD# </b>32<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Skyway<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10480ft<br><b>PM </b>6th<br><b>Township </b>12S<br><b>Range </b>96W<br><b>Section </b>14<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.29368, -108.38332),
  title: "6/20/2015",
  sidebarItem: "6/20/2015",
  content: "<b>Site# </b>6/20/2015<br><b>FSD# </b>33<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>n/a<br><b>Description </b>small flake<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Big Bucktail Creek<br><b>County </b>Montrose<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>6520ft<br><b>PM </b>NM<br><b>Township </b>47N<br><b>Range </b>14W<br><b>Section </b>26<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.01926, -108.11884),
  title: "5ME5679",
  sidebarItem: "5ME5679",
  content: "<b>Site# </b>5ME5679<br><b>FSD# </b>34<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>1<br><b>Description </b>flake<br><b>Geochemical Source </b>Malad, ID<br><b>Quad Map </b>Skyway<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10360ft<br><b>PM </b>6th<br><b>Township </b>12S<br><b>Range </b>96W<br><b>Section </b>9<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.24069, -107.57124),
  title: "5ME6545",
  sidebarItem: "5ME6545",
  content: "<b>Site# </b>5ME6545<br><b>FSD# </b>37<br><b>Artifact Type </b>Chunk<br><b>Artifact# </b>s1<br><b>Description </b>large obsidian chunk<br><b>Geochemical Source </b>Obsidian Cliff, WY<br><b>Quad Map </b>Spruce Mountain<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>8940ft<br><b>PM </b>6th<br><b>Township </b>9S<br><b>Range </b>91W<br><b>Section </b>29<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.40356, -108.1785),
  title: "5MN2628",
  sidebarItem: "5MN2628",
  content: "<b>Site# </b>5MN2628<br><b>FSD# </b>38<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s9<br><b>Description </b>large utilized flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Davis Point<br><b>County </b>Montrose<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>8400ft<br><b>PM </b>NM<br><b>Township </b>48N<br><b>Range </b>12W<br><b>Section </b>22<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.2429, -108.28071),
  title: "5MN3463",
  sidebarItem: "5MN3463",
  content: "<b>Site# </b>5MN3463<br><b>FSD# </b>39<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s3<br><b>Description </b>flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Norwood<br><b>County </b>Montrose<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>7760ft<br><b>PM </b>NM<br><b>Township </b>46N<br><b>Range </b>13W<br><b>Section </b>15<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.24446, -108.29367),
  title: "5MN3549",
  sidebarItem: "5MN3549",
  content: "<b>Site# </b>5MN3549<br><b>FSD# </b>40<br><b>Artifact Type </b>Biface<br><b>Artifact# </b>s2<br><b>Description </b>biface fragment<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Norwood<br><b>County </b>Montrose<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>7760ft<br><b>PM </b>NM<br><b>Township </b>46N<br><b>Range </b>13W<br><b>Section </b>15<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.45781, -108.332),
  title: "5MN3685",
  sidebarItem: "5MN3685",
  content: "<b>Site# </b>5MN3685<br><b>FSD# </b>41<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>n/a<br><b>Description </b>small flake<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Montrose Mesa<br><b>County </b>Montrose<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>8440ft<br><b>PM </b>NM<br><b>Township </b>48N<br><b>Range </b>13W<br><b>Section </b>5<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.213, -108.22187),
  title: "5MN3779",
  sidebarItem: "5MN3779",
  content: "<b>Site# </b>5MN3779<br><b>FSD# </b>42<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s30<br><b>Description </b>flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Sanborn Park<br><b>County </b>Montrose<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>7880ft<br><b>PM </b>NM<br><b>Township </b>46N<br><b>Range </b>12W<br><b>Section </b>29<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.20662, -108.24866),
  title: "5MN3781",
  sidebarItem: "5MN3781",
  content: "<b>Site# </b>5MN3781<br><b>FSD# </b>44<br><b>Artifact Type </b>Biface<br><b>Artifact# </b>s1<br><b>Description </b>biface fragment<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Sanborn Park<br><b>County </b>Montrose<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>7540ft<br><b>PM </b>NM<br><b>Township </b>46N<br><b>Range </b>13W<br><b>Section </b>25<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.43254, -108.28344),
  title: "5MN4093",
  sidebarItem: "5MN4093",
  content: "<b>Site# </b>5MN4093<br><b>FSD# </b>45<br><b>Artifact Type </b>Biface<br><b>Artifact# </b>5<br><b>Description </b>biface fragment<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Moore Mesa<br><b>County </b>Montrose<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>8890ft<br><b>PM </b>NM<br><b>Township </b>48N<br><b>Range </b>13W<br><b>Section </b>10<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.33846, -108.43535),
  title: "5MN6252",
  sidebarItem: "5MN6252",
  content: "<b>Site# </b>5MN6252<br><b>FSD# </b>46<br><b>Artifact Type </b>Blade<br><b>Artifact# </b>s1<br><b>Description </b>blade tip<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Big Bucktail Creek<br><b>County </b>Montrose<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>7040ft<br><b>PM </b>NM<br><b>Township </b>47N<br><b>Range </b>14W<br><b>Section </b>8<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.29589, -108.37994),
  title: "5MN7367",
  sidebarItem: "5MN7367",
  content: "<b>Site# </b>5MN7367<br><b>FSD# </b>47<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>n/a<br><b>Description </b>projectile point<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Big Bucktail Creek<br><b>County </b>Montrose<br><b>Temporal Cultural Association </b>Late Prehistoric<br><b>Elevation </b>6680ft<br><b>PM </b>NM<br><b>Township </b>47N<br><b>Range </b>14W<br><b>Section </b>26<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.20213, -108.06439),
  title: "5MN7821",
  sidebarItem: "5MN7821",
  content: "<b>Site# </b>5MN7821<br><b>FSD# </b>48<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>n/a<br><b>Description </b>medium flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Hotchkiss Reservior<br><b>County </b>Montrose<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>8430ft<br><b>PM </b>NM<br><b>Township </b>46N<br><b>Range </b>11W<br><b>Section </b>34<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.27174, -106.62638),
  title: "5SH447",
  sidebarItem: "5SH447",
  content: "<b>Site# </b>5SH447<br><b>FSD# </b>50<br><b>Artifact Type </b>Chunk<br><b>Artifact# </b>n/a<br><b>Description </b>chunk<br><b>Geochemical Source </b>Cochetopa Dome, CO<br><b>Quad Map </b>Razor Creek Dome<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10200ft<br><b>PM </b>NM<br><b>Township </b>46N<br><b>Range </b>3E<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.14844, -106.63668),
  title: "5SH1075",
  sidebarItem: "5SH1075",
  content: "<b>Site# </b>5SH1075<br><b>FSD# </b>51<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>s9<br><b>Description </b>projectile point fragment, middle Archaic stemmed<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Cochetopa Park<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>Middle Archaic<br><b>Elevation </b>9850ft<br><b>PM </b>NM<br><b>Township </b>45N<br><b>Range </b>3E<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.15077, -106.66853),
  title: "5SH1076",
  sidebarItem: "5SH1076",
  content: "<b>Site# </b>5SH1076<br><b>FSD# </b>52<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s5<br><b>Description </b>blade flake<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Cochetopa Park<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9390ft<br><b>PM </b>NM<br><b>Township </b>45N<br><b>Range </b>3E<br><b>Section </b>20<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.14994, -106.6471),
  title: "5SH1335",
  sidebarItem: "5SH1335",
  content: "<b>Site# </b>5SH1335<br><b>FSD# </b>54<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s4<br><b>Description </b>utilized flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Cochetopa Park<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9600ft<br><b>PM </b>NM<br><b>Township </b>45N<br><b>Range </b>3E<br><b>Section </b>21<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.14898, -106.65377),
  title: "5SH1337",
  sidebarItem: "5SH1337",
  content: "<b>Site# </b>5SH1337<br><b>FSD# </b>55<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s6<br><b>Description </b>medium flake<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Cochetopa Park<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9670ft<br><b>PM </b>NM<br><b>Township </b>45N<br><b>Range </b>3E<br><b>Section </b>21<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.14806, -106.63125),
  title: "5SH1343",
  sidebarItem: "5SH1343",
  content: "<b>Site# </b>5SH1343<br><b>FSD# </b>56<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s11<br><b>Description </b>utilized flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Cochetopa Park<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9700ft<br><b>PM </b>NM<br><b>Township </b>45N<br><b>Range </b>3E<br><b>Section </b>22<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.23504, -106.63493),
  title: "5SH1398",
  sidebarItem: "5SH1398",
  content: "<b>Site# </b>5SH1398<br><b>FSD# </b>57<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s2<br><b>Description </b>utilized flake, possible scraper<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Cochetopa Park<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9400ft<br><b>PM </b>NM<br><b>Township </b>46N<br><b>Range </b>3E<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.23591, -106.63061),
  title: "5SH1400",
  sidebarItem: "5SH1400",
  content: "<b>Site# </b>5SH1400<br><b>FSD# </b>58<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>s1<br><b>Description </b>prior stemmed Paleo Indian point, broken<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Cochetopa Park<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>Late Paleo Indian<br><b>Elevation </b>9780ft<br><b>PM </b>NM<br><b>Township </b>46N<br><b>Range </b>3E<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.23042, -106.61027),
  title: "5SH1406",
  sidebarItem: "5SH1406",
  content: "<b>Site# </b>5SH1406<br><b>FSD# </b>60<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>utilized flake<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>North Pass<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9760ft<br><b>PM </b>NM<br><b>Township </b>46N<br><b>Range </b>3E<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.23042, -106.61027),
  title: "5SH1406",
  sidebarItem: "5SH1406",
  content: "<b>Site# </b>5SH1406<br><b>FSD# </b>61<br><b>Artifact Type </b>Scraper<br><b>Artifact# </b>s10<br><b>Description </b>bifacial scraper<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>North Pass<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9760ft<br><b>PM </b>NM<br><b>Township </b>46N<br><b>Range </b>3E<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.24361, -106.63642),
  title: "5SH1409",
  sidebarItem: "5SH1409",
  content: "<b>Site# </b>5SH1409<br><b>FSD# </b>62<br><b>Artifact Type </b>Spoke Shave<br><b>Artifact# </b>s18<br><b>Description </b>spoke shave<br><b>Geochemical Source </b>Cochetopa Dome, CO<br><b>Quad Map </b>Cochetopa Park<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9800ft<br><b>PM </b>NM<br><b>Township </b>46N<br><b>Range </b>3E<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.36631, -106.33868),
  title: "5SH193",
  sidebarItem: "5SH193",
  content: "<b>Site# </b>5SH193<br><b>FSD# </b>63<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>n/a<br><b>Description </b>utilized flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Chester<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9100ft<br><b>PM </b>NM<br><b>Township </b>48N<br><b>Range </b>6E<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.37255, -106.34452),
  title: "5SH197",
  sidebarItem: "5SH197",
  content: "<b>Site# </b>5SH197<br><b>FSD# </b>64<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>n/a<br><b>Description </b>medium flake<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Chester<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9120ft<br><b>PM </b>NM<br><b>Township </b>48N<br><b>Range </b>6E<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.21079, -106.84393),
  title: "5SH2259",
  sidebarItem: "5SH2259",
  content: "<b>Site# </b>5SH2259<br><b>FSD# </b>65<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>n/a<br><b>Description </b>bifacially worked base<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Gold Spring Park<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>Unknown<br><b>Elevation </b>9360ft<br><b>PM </b>NM<br><b>Township </b>46N<br><b>Range </b>1E<br><b>Section </b>34<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.14364, -106.80779),
  title: "5SH2344",
  sidebarItem: "5SH2344",
  content: "<b>Site# </b>5SH2344<br><b>FSD# </b>66<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>n/a<br><b>Description </b>medium flake<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Gold Spring Park<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10000ft<br><b>PM </b>NM<br><b>Township </b>45N<br><b>Range </b>2E<br><b>Section </b>30<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.01358, -106.82544),
  title: "5SH2345",
  sidebarItem: "5SH2345",
  content: "<b>Site# </b>5SH2345<br><b>FSD# </b>67<br><b>Artifact Type </b>Drill<br><b>Artifact# </b>n/a<br><b>Description </b>projectile point repurposed as a drill<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Elk Park<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10340ft<br><b>PM </b>NM<br><b>Township </b>43N<br><b>Range </b>1E<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.3019, -106.58356),
  title: "5SH3046",
  sidebarItem: "5SH3046",
  content: "<b>Site# </b>5SH3046<br><b>FSD# </b>68<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>n/a<br><b>Description </b>flake<br><b>Geochemical Source </b>Cerro Toledo Rhy, NM<br><b>Quad Map </b>West Baldy<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9620ft<br><b>PM </b>NM<br><b>Township </b>47N<br><b>Range </b>3E<br><b>Section </b>25<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.09631, -106.70113),
  title: "5SH3956",
  sidebarItem: "5SH3956",
  content: "<b>Site# </b>5SH3956<br><b>FSD# </b>69<br><b>Artifact Type </b>Biface<br><b>Artifact# </b>lah5<br><b>Description </b>biface fragment<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Saguache Park<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10300ft<br><b>PM </b>NM<br><b>Township </b>44N<br><b>Range </b>2E<br><b>Section </b>1<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.1051, -106.69475),
  title: "5SH3957",
  sidebarItem: "5SH3957",
  content: "<b>Site# </b>5SH3957<br><b>FSD# </b>70<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>s1<br><b>Description </b>projectile point, Middle Archaic stem<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Saguache Park<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>Middle Archaic<br><b>Elevation </b>9850ft<br><b>PM </b>NM<br><b>Township </b>44N<br><b>Range </b>3E<br><b>Section </b>6<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(37.90777, -108.17585),
  title: "5SM129",
  sidebarItem: "5SM129",
  content: "<b>Site# </b>5SM129<br><b>FSD# </b>71<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>n/a<br><b>Description </b>medium flake<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Beaver Park<br><b>County </b>San Miguel<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9000ft<br><b>PM </b>NM<br><b>Township </b>42N<br><b>Range </b>12W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(37.91686, -108.18301),
  title: "5SM1214",
  sidebarItem: "5SM1214",
  content: "<b>Site# </b>5SM1214<br><b>FSD# </b>72<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>n/a<br><b>Description </b>large flake<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Beaver Park<br><b>County </b>San Miguel<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>9040ft<br><b>PM </b>NM<br><b>Township </b>42N<br><b>Range </b>12W<br><b>Section </b>10<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.01471, -108.23621),
  title: "5SM1503",
  sidebarItem: "5SM1503",
  content: "<b>Site# </b>5SM1503<br><b>FSD# </b>74<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>s19<br><b>Description </b>projectile point base<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Gurley Canyon<br><b>County </b>San Miguel<br><b>Temporal Cultural Association </b>Middle Archaic Duncan<br><b>Elevation </b>8310ft<br><b>PM </b>NM<br><b>Township </b>43N<br><b>Range </b>12W<br><b>Section </b>6<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(37.9442, -107.89814),
  title: "5SM1527",
  sidebarItem: "5SM1527",
  content: "<b>Site# </b>5SM1527<br><b>FSD# </b>75<br><b>Artifact Type </b>Biface<br><b>Artifact# </b>s1<br><b>Description </b>biface midsection<br><b>Geochemical Source </b>El Rechuelos, NM<br><b>Quad Map </b>Gray Head<br><b>County </b>San Miguel<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>8070ft<br><b>PM </b>NM<br><b>Township </b>43N<br><b>Range </b>9W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.00032, -108.27171),
  title: "5SM2303",
  sidebarItem: "5SM2303",
  content: "<b>Site# </b>5SM2303<br><b>FSD# </b>76<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>small flake<br><b>Geochemical Source </b>Malad, ID<br><b>Quad Map </b>Oak Hill<br><b>County </b>San Miguel<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>8240ft<br><b>PM </b>NM<br><b>Township </b>43N<br><b>Range </b>13W<br><b>Section </b>11<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.22671, -106.61562),
  title: "5SH1412",
  sidebarItem: "5SH1412",
  content: "<b>Site# </b>5SH1412<br><b>FSD# </b>79<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>s9<br><b>Description </b>possible Coal Creek projectile point, broken<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>North Pass<br><b>County </b>Saguache<br><b>Temporal Cultural Association </b>Middle Archaic<br><b>Elevation </b>9700ft<br><b>PM </b>NM<br><b>Township </b>46N<br><b>Range </b>3E<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.08696, -107.92793),
  title: "5ME1334",
  sidebarItem: "5ME1334",
  content: "<b>Site# </b>5ME1334<br><b>FSD# </b>80<br><b>Artifact Type </b>Biface<br><b>Artifact# </b>s5<br><b>Description </b>biface fragment<br><b>Geochemical Source </b>Valles Rhy-Cerro del Medio, NM<br><b>Quad Map </b>Grand Mesa<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>n/a<br><b>Elevation </b>10320ft<br><b>PM </b>6th<br><b>Township </b>11S<br><b>Range </b>94W<br><b>Section </b>0<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.2876, -108.50141),
  title: "5ME21160",
  sidebarItem: "5ME21160",
  content: "<b>Site# </b>5ME21160<br><b>FSD# </b>81<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>s3<br><b>Description </b>Sinbad projectile point tip<br><b>Geochemical Source </b>Malad, ID<br><b>Quad Map </b>Corcoran Peak<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>Middle Archaic<br><b>Elevation </b>6640ft<br><b>PM </b>6th<br><b>Township </b>9S<br><b>Range </b>100W<br><b>Section </b>12<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.267323, -108.15871),
  title: "5ME16789",
  sidebarItem: "5ME16789",
  content: "<b>Site# </b>5ME16789<br><b>Artifact Type </b>Tool<br><b>Artifact# </b>2.fs96<br><b>Description </b>tool<br><b>Geochemical Source </b>Cerro del Medio, NM<br><b>Quad Map </b>DeBeque (1962)<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>Middle Archaic<br><b>Elevation </b>6000ft<br><b>PM </b>6th<br><b>Township </b>9S<br><b>Range </b>97W<br><b>Section </b>13<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.267323, -108.15871),
  title: "5ME16789",
  sidebarItem: "5ME16789",
  content: "<b>Site# </b>5ME16789<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>fs96<br><b>Description </b>projectile point midsection<br><b>Geochemical Source </b>Polvadera Peak, NM<br><b>Quad Map </b>DeBeque (1962)<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>Middle Archaic<br><b>Elevation </b>6000ft<br><b>PM </b>6th<br><b>Township </b>9S<br><b>Range </b>97W<br><b>Section </b>13<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.897734, -108.383926),
  title: "5RB382",
  sidebarItem: "5RB382",
  content: "<b>Site# </b>5RB382<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>flake<br><b>Geochemical Source </b>Malad, ID<br><b>Quad Map </b>Wolf Ridge (1952)<br><b>County </b>Rio Blanco<br><b>Temporal Cultural Association </b>Unknown, Late Prehistoric<br><b>Elevation </b>6600ft<br><b>PM </b>6th<br><b>Township </b>2S<br><b>Range </b>98W<br><b>Section </b>10<br><b>Datum </b>NAD27 (adjusted to NAD83)"
});
makeMarker({
  position: new google.maps.LatLng(39.912405, -108.379367),
  title: "5RB400",
  sidebarItem: "5RB400",
  content: "<b>Site# </b>5RB400<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s3<br><b>Description </b>flake<br><b>Geochemical Source </b>Black Rock Area<br><b>Quad Map </b>Wolf Ridge (1960)<br><b>County </b>Rio Blanco<br><b>Temporal Cultural Association </b>Unknown<br><b>Elevation </b>6720ft<br><b>PM </b>6th<br><b>Township </b>1S<br><b>Range </b>98W<br><b>Section </b>34<br><b>Datum </b>NAD27 (adjusted to NAD83)"
});
makeMarker({
  position: new google.maps.LatLng(39.912405, -108.379367),
  title: "5RB400",
  sidebarItem: "5RB400",
  content: "<b>Site# </b>5RB400<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s4<br><b>Description </b>flake<br><b>Geochemical Source </b>Malad, ID<br><b>Quad Map </b>Wolf Ridge (1960)<br><b>County </b>Rio Blanco<br><b>Temporal Cultural Association </b>Unknown<br><b>Elevation </b>6720ft<br><b>PM </b>6th<br><b>Township </b>1S<br><b>Range </b>98W<br><b>Section </b>34<br><b>Datum </b>NAD27 (adjusted to NAD83)"
});
makeMarker({
  position: new google.maps.LatLng(39.907758, -108.387838),
  title: "5RB605",
  sidebarItem: "5RB605",
  content: "<b>Site# </b>5RB605<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s2<br><b>Description </b>flake<br><b>Geochemical Source </b>Wild Horse Canyon, UT<br><b>Quad Map </b>Wolf Ridge (1960)<br><b>County </b>Rio Blanco<br><b>Temporal Cultural Association </b>Late Prehistoric<br><b>Elevation </b>6700ft<br><b>PM </b>6th<br><b>Township </b>2S<br><b>Range </b>98W<br><b>Section </b>4<br><b>Datum </b>NAD27 (adjusted to NAD83)"
});
makeMarker({
  position: new google.maps.LatLng(39.907758, -108.387838),
  title: "5RB605",
  sidebarItem: "5RB605",
  content: "<b>Site# </b>5RB605<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s3<br><b>Description </b>flake<br><b>Geochemical Source </b>Black Rock Area<br><b>Quad Map </b>Wolf Ridge (1960)<br><b>County </b>Rio Blanco<br><b>Temporal Cultural Association </b>Late Prehistoric<br><b>Elevation </b>6700ft<br><b>PM </b>6th<br><b>Township </b>2S<br><b>Range </b>98W<br><b>Section </b>4<br><b>Datum </b>NAD27 (adjusted to NAD83)"
});
makeMarker({
  position: new google.maps.LatLng(39.893494, -108.397279),
  title: "5RB4531",
  sidebarItem: "5RB4531",
  content: "<b>Site# </b>5RB4531<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>s1<br><b>Description </b>notched projectile point<br><b>Geochemical Source </b>Wild Horse Canyon, UT<br><b>Quad Map </b>Wolf Ridge (1960)<br><b>County </b>Rio Blanco<br><b>Temporal Cultural Association </b>Formative<br><b>Elevation </b>6640ft<br><b>PM </b>6th<br><b>Township </b>2S<br><b>Range </b>98W<br><b>Section </b>9<br><b>Datum </b>NAD27 (adjusted to NAD83)"
});
makeMarker({
  position: new google.maps.LatLng(39.893494, -108.397279),
  title: "5RB4532",
  sidebarItem: "5RB4532",
  content: "<b>Site# </b>5RB4532<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>flake<br><b>Geochemical Source </b>Wild Horse Canyon, UT<br><b>Quad Map </b>Wolf Ridge (1952)<br><b>County </b>Rio Blanco<br><b>Temporal Cultural Association </b>Unknown<br><b>Elevation </b>6710ft<br><b>PM </b>6th<br><b>Township </b>2S<br><b>Range </b>98W<br><b>Section </b>9<br><b>Datum </b>NAD27 (adjusted to NAD83)"
});
makeMarker({
  position: new google.maps.LatLng(39.888795, -108.402217),
  title: "5RB4532",
  sidebarItem: "5RB4532",
  content: "<b>Site# </b>5RB4532<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>s7<br><b>Description </b>Cottonwood triangular<br><b>Geochemical Source </b>Malad, ID<br><b>Quad Map </b>Wolf Ridge (1952)<br><b>County </b>Rio Blanco<br><b>Temporal Cultural Association </b>Unknown<br><b>Elevation </b>6710ft<br><b>PM </b>6th<br><b>Township </b>2S<br><b>Range </b>98W<br><b>Section </b>9<br><b>Datum </b>NAD27 (adjusted to NAD83)"
});
makeMarker({
  position: new google.maps.LatLng(39.904009, -108.390167),
  title: "5RB7749",
  sidebarItem: "5RB7749",
  content: "<b>Site# </b>5RB7749<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>flake<br><b>Geochemical Source </b>Wild Horse Canyon, UT<br><b>Quad Map </b>Wolf Ridge (1952)<br><b>County </b>Rio Blanco<br><b>Temporal Cultural Association </b>Ute<br><b>Elevation </b>6640ft<br><b>PM </b>6th<br><b>Township </b>2S<br><b>Range </b>98W<br><b>Section </b>4<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.889395, -108.39927),
  title: "5RB7778",
  sidebarItem: "5RB7778",
  content: "<b>Site# </b>5RB7778<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>flake<br><b>Geochemical Source </b>Malad, ID<br><b>Quad Map </b>Wolf Ridge (1952)<br><b>County </b>Rio Blanco<br><b>Temporal Cultural Association </b>Ute<br><b>Elevation </b>6650ft<br><b>PM </b>6th<br><b>Township </b>2S<br><b>Range </b>98W<br><b>Section </b>9<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.908142, -108.390115),
  title: "5RB7833",
  sidebarItem: "5RB7833",
  content: "<b>Site# </b>5RB7833<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>flake<br><b>Geochemical Source </b>Wild Horse Canyon, UT<br><b>Quad Map </b>Wolf Ridge (1952)<br><b>County </b>Rio Blanco<br><b>Temporal Cultural Association </b>Ute<br><b>Elevation </b>6635ft<br><b>PM </b>6th<br><b>Township </b>2S<br><b>Range </b>98W<br><b>Section </b>4<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(39.438609, -108.777276),
  title: "5GF741",
  sidebarItem: "5GF741",
  content: "<b>Site# </b>5GF741<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>fs45<br><b>Description </b>projectile point<br><b>Geochemical Source </b>Malad, ID<br><b>Quad Map </b>Howard Canyon (1968)<br><b>County </b>Garfield<br><b>Temporal Cultural Association </b>Early Middle Archaic<br><b>Elevation </b>5400ft<br><b>PM </b>6th<br><b>Township </b>7S<br><b>Range </b>102W<br><b>Section </b>21<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.221867, -108.401806),
  title: "5ME15343",
  sidebarItem: "5ME15343",
  content: "<b>Site# </b>5ME15343<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>long blade flake<br><b>Geochemical Source </b>Unknown<br><b>Quad Map </b>Triangle Mesa (1969)<br><b>County </b>Montrose<br><b>Temporal Cultural Association </b>Unknown Late Prehistoric<br><b>Elevation </b>4921ft<br><b>PM </b>6th<br><b>Township </b>14S<br><b>Range </b>98W<br><b>Section </b>19<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.221867, -108.401806),
  title: "5ME15343",
  sidebarItem: "5ME15343",
  content: "<b>Site# </b>5ME15343<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>n/a<br><b>Description </b>flake<br><b>Geochemical Source </b>Unknown<br><b>Quad Map </b>Triangle Mesa (1969)<br><b>County </b>Montrose<br><b>Temporal Cultural Association </b>Unknown Late Prehistoric<br><b>Elevation </b>4921ft<br><b>PM </b>6th<br><b>Township </b>14S<br><b>Range </b>98W<br><b>Section </b>19<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(40.42807, -109.004811),
  title: "5MF6919",
  sidebarItem: "5MF6919",
  content: "<b>Site# </b>5MF6919<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>s1<br><b>Description </b>flake<br><b>Geochemical Source </b>Obsidian Ridge, NM<br><b>Quad Map </b>Stuntz Reservior (1955)<br><b>County </b>Moffat<br><b>Temporal Cultural Association </b>Unknown Late Prehistoric<br><b>Elevation </b>7720ft<br><b>PM </b>6th<br><b>Township </b>6N<br><b>Range </b>103W<br><b>Section </b>31<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(38.646324, -108.794807),
  title: "5ME17916",
  sidebarItem: "5ME17916",
  content: "<b>Site# </b>5ME17916<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>s3<br><b>Description </b>projectile point fragment<br><b>Geochemical Source </b>Polvadera Peak, NM<br><b>Quad Map </b>Calamity Mesa (1972)<br><b>County </b>Mesa<br><b>Temporal Cultural Association </b>Formative<br><b>Elevation </b>5600ft<br><b>PM </b>NM<br><b>Township </b>50N<br><b>Range </b>17W<br><b>Section </b>30<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(40.09031, -106.266183),
  title: "5GA4222",
  sidebarItem: "5GA4222",
  content: "<b>Site# </b>5GA4222<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>1.1<br><b>Description </b>flake<br><b>Geochemical Source </b>Obsidian Cliff, WY<br><b>Quad Map </b>Junction Butte (1980)<br><b>County </b>Grand<br><b>Temporal Cultural Association </b>Late Prehistoric<br><b>Elevation </b>7640ft<br><b>PM </b>6th<br><b>Township </b>2N<br><b>Range </b>79W<br><b>Section </b>32<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(40.09031, -106.266183),
  title: "5GA4222",
  sidebarItem: "5GA4222",
  content: "<b>Site# </b>5GA4222<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>1.2<br><b>Description </b>flake<br><b>Geochemical Source </b>Obsidian Cliff, WY<br><b>Quad Map </b>Junction Butte (1980)<br><b>County </b>Grand<br><b>Temporal Cultural Association </b>Late Prehistoric<br><b>Elevation </b>7640ft<br><b>PM </b>6th<br><b>Township </b>2N<br><b>Range </b>79W<br><b>Section </b>32<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(40.092151, -106.265079),
  title: "5GA4217",
  sidebarItem: "5GA4217",
  content: "<b>Site# </b>5GA4217<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>1<br><b>Description </b>flake<br><b>Geochemical Source </b>Polvadera Peak, NM<br><b>Quad Map </b>Junction Butte (1980)<br><b>County </b>Grand<br><b>Temporal Cultural Association </b>Unknown<br><b>Elevation </b>7725ft<br><b>PM </b>6th<br><b>Township </b>2N<br><b>Range </b>79W<br><b>Section </b>32<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(40.092151, -106.265079),
  title: "5GA4217",
  sidebarItem: "5GA4217",
  content: "<b>Site# </b>5GA4217<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>4<br><b>Description </b>flake<br><b>Geochemical Source </b>Polvadera Peak, NM<br><b>Quad Map </b>Junction Butte (1980)<br><b>County </b>Grand<br><b>Temporal Cultural Association </b>Unknown<br><b>Elevation </b>7725ft<br><b>PM </b>6th<br><b>Township </b>2N<br><b>Range </b>79W<br><b>Section </b>32<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(40.092151, -106.265079),
  title: "5GA4217",
  sidebarItem: "5GA4217",
  content: "<b>Site# </b>5GA4217<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>8<br><b>Description </b>flake<br><b>Geochemical Source </b>Polvadera Peak, NM<br><b>Quad Map </b>Junction Butte (1980)<br><b>County </b>Grand<br><b>Temporal Cultural Association </b>Unknown<br><b>Elevation </b>7725ft<br><b>PM </b>6th<br><b>Township </b>2N<br><b>Range </b>79W<br><b>Section </b>32<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(40.092151, -106.265079),
  title: "5GA4217",
  sidebarItem: "5GA4217",
  content: "<b>Site# </b>5GA4217<br><b>Artifact Type </b>Flake<br><b>Artifact# </b>9<br><b>Description </b>flake<br><b>Geochemical Source </b>Polvadera Peak, NM<br><b>Quad Map </b>Junction Butte (1980)<br><b>County </b>Grand<br><b>Temporal Cultural Association </b>Unknown<br><b>Elevation </b>7725ft<br><b>PM </b>6th<br><b>Township </b>2N<br><b>Range </b>79W<br><b>Section </b>32<br><b>Datum </b>NAD83"
});
makeMarker({
  position: new google.maps.LatLng(40.217955, -108.747927),
  title: "5RB1020",
  sidebarItem: "5RB1020",
  content: "<b>Site# </b>5RB1020<br><b>Artifact Type </b>Projectile Point<br><b>Artifact# </b>s2<br><b>Description </b>projectile point tip<br><b>Geochemical Source </b>Malad, ID<br><b>Quad Map </b>Cactus Reservior (1962)<br><b>County </b>Rio Blanco<br><b>Temporal Cultural Association </b>Ute<br><b>Elevation </b>5790ft<br><b>PM </b>6th<br><b>Township </b>3N<br><b>Range </b>101W<br><b>Section </b>20<br><b>Datum </b>NAD83"
});



//fit view to marker
map.fitBounds(markerBounds);



</script>
  <div id="default" style="width:100%; height:100%"></div>
</body>
</html>
