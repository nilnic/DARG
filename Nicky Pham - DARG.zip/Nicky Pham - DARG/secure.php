<?php
$user = $_POST['dargnet'];
$pass = $_POST['500scraper'];

if($user == "admin"
&& $pass == "admin")
{
        include("Index.com/#tabs-6");
}
else
{
    if(isset($_POST))
    {?>

            <form method="POST" action="secure.php">
            User <input type="text" name="user"></input><br/>
            Pass <input type="password" name="pass"></input><br/>
            <input type="submit" name="submit" value="Go"></input>
            </form>
    <?}
}
?>