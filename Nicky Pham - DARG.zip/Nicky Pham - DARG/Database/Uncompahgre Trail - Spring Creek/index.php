<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta property="og:site_name" content="Dominquez Archaeological Research Group"/>
	<meta property="og:title" content="Spring Creek Database"/>
	<meta property="og:description" content="Dominquez Archaeological Research Group (DARG) is a non-profit corporation established in 2003 as a consortium for anthropological and archaeological research, preservation and education in the Upper Colorado River ."/>
	<meta property="og:image" content="Image/DARG_logo_clear_back_large.png"/>
	<title>Spring Creek Database</title>
	
	<link rel="stylesheet" href="css/main.css">
	<script type="text/javascript" src="js/topbutton.js"></script> 
	
</head>
<body>
<div id="header">
<img src="image/DARG Header.png" alt="Dominguez Anthropological Research Group" align="middle" height="100px" width="auto">
</div>
<div class="homelink">
	<a href="https://www.dargnet.org"><img src="image/icones-png-theme-home-19.png" width="65" height="65" alt="Home"/></a>
	<style>
		.homelink {font-weight: bold; text-align: center; margin-top: -16px; margin-bottom: -80px;}
	</style>
</div>
<div class="projectname">	
	<h2>Uncompahgre Trail - Spring Creek Database</h2>
	<h5>For more information contact:<br>
		Carl Conner, Project Director<br>
		darg.colorado@gmail.com</h5>
	<style>
		.projectname {text-align: center; margin-top: 85px;}
	</style>
</div>


<!--Get DB Connection Info --!>
<?php
require 'connect.inc.php';
?>




<!-- Dynamic Map Test 


<div class="Map">

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3031.0760068303753!2d-105.08149758430818!3d40.56199875471497!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87694b07487a4ae3%3A0xff5193430e56f889!2sSpring+Creek+Trail%2C+Fort+Collins%2C+CO!5e0!3m2!1sen!2sus!4v1512774009611" width="100%" height="500" frameborder="0" style="border:0" allowfullscreen></iframe>

</div>



-->



































<!-- Site Name Search -->
<div class="userinput1">
<form class="SearchBox" action="index.php" method="POST">
	<h4>Site Number: </h4>
	<input type="text" name="search_site"><br><br>
	<input type="submit" value="Search">	
</form>
</div>

<div class="result">
<?php
	if (isset($_POST['search_site'])) {
		$search_site = $_POST['search_site'];
	if (!empty($search_site)) {
		
		if (strlen($search_site)>=2) {
		
		
			$query = "SELECT * FROM springcreek WHERE Site LIKE '%".mysql_real_escape_string($search_site)."%'";
			$query_run = mysql_query($query);
			$query_num_rows = mysql_num_rows($query_run);
			
			if ($query_num_rows>=1) {
				echo '<br><h4>'.$query_num_rows.' out of 137 results are found with "'.$search_site.'":</h4>';
				while ($query_row= mysql_fetch_assoc($query_run)) 
				{?>
					<table style="width: 100%; text-align: center;">
    					<tr>
        					<th width="60px">Site</th>
							<th width="100px">Site Type</th>
							<th width="40px">ID</th>
							<th width="50px">Area</th>
							<th width="50px">Perimeter</th>
							<th width="50px">Acres</th>
							<th width="70px">Date Recorded</th>
							<th width="30px">Confidence</th>
							<th width="40px">Boundary Complete</th>
							<th width="40px">Linear</th>
							<th width="40px">Zone</th>
							<th width="100px">Recorder</th>
							<th width="40px">Collected</th>
							<th width="100px">Artifacts</th>
							<th width="40px">Diagnostic</th>
							<th width="100px">Cultural Affiliation</th>
							
						</tr>
						<tr>
							<td width="60px"><?php echo '<center>'.$query_row['Site'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Site Type'].'<br>'; ?></td>
							<td width="40px"><?php echo '<center>'.$query_row['ID'].'<br>'; ?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Area'].'<br>';?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Perimeter'].'<br>';?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Acres'].'<br>';?></td>
							<td width="70px"><?php echo '<center>'.$query_row['Date'].'<br>';?></td>
							<td width="30px"><?php echo '<center>'.$query_row['Confidence'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Boundary Complete'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Linear'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Zone'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Recorder'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Collected'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Artifacts'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Diagnostic'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Cultural Affiliation'].'<br>';?></td>
							
						</tr>
					</table>
					<?php
				}
			}	else {
				echo '<br><br><br>No result found for "'.$search_site.'" as Site Number.';
			}
		}	else {
			echo '<br><br><br>Your keyword must be 2 characters or more.';
		}
	}
	}
?>
</div>


<!-- Site Type Drop Down Menu -->
<div class="userinput2">
<form class="SiteTypeDD" action="index.php" method="GET">
	<h4>Select A Site Type:</h4>
	<select name="SiteType">
		<option value"Archaeological">Archaeological</option>
		<option value"Historical Archaeology">Historical Archaeology</option>
		<option value"Historic | Historicalarchaeology">Historic | Historical Archaeology</option>
		<option value"Archaeological | Historical Archaeology">Archaeological | Historical Archaeology</option>
	</select><br><br>

	<input type="submit" value="Submit">	
</form>
</div>

<div class="result">
<?php
if (isset($_GET['SiteType'])&&!empty($_GET['SiteType'])) {
	
	$SiteType = ($_GET['SiteType']);

	if ($SiteType=='Archaeological'||$SiteType=='Historical Archaeology'||$SiteType=='Historic | Historical Archaeology'||$SiteType=='Archaeological | Historical Archaeology') {
	
		// Setting Loop//
		$query = "SELECT * FROM springcreek WHERE `Site Type`='$SiteType' ORDER BY Site DESC";

		// Start Loop//
		if ($query_run = mysql_query($query)) {
			
			$query_num_rows = mysql_num_rows($query_run);

			if ($query_num_rows==NULL) {
				echo 'No results found.';
			}	else {
			
			echo '<br><h4>'.$query_num_rows.' out of 137 sites are '.$SiteType.':</h4>';		
			while ($query_row = mysql_fetch_assoc($query_run)) {?>
				<table style="width: 100%; text-align: center;">
    					<tr>
        					<th width="60px">Site</th>
							<th width="100px">Site Type</th>
							<th width="40px">ID</th>
							<th width="50px">Area</th>
							<th width="50px">Perimeter</th>
							<th width="50px">Acres</th>
							<th width="70px">Date Recorded</th>
							<th width="30px">Confidence</th>
							<th width="40px">Boundary Complete</th>
							<th width="40px">Linear</th>
							<th width="40px">Zone</th>
							<th width="100px">Recorder</th>
							<th width="40px">Collected</th>
							<th width="100px">Artifacts</th>
							<th width="40px">Diagnostic</th>
							<th width="100px">Cultural Affiliation</th>
							
						</tr>
						<tr>
							<td width="60px"><?php echo '<center>'.$query_row['Site'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Site Type'].'<br>'; ?></td>
							<td width="40px"><?php echo '<center>'.$query_row['ID'].'<br>'; ?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Area'].'<br>';?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Perimeter'].'<br>';?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Acres'].'<br>';?></td>
							<td width="70px"><?php echo '<center>'.$query_row['Date'].'<br>';?></td>
							<td width="30px"><?php echo '<center>'.$query_row['Confidence'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Boundary Complete'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Linear'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Zone'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Recorder'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Collected'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Artifacts'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Diagnostic'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Cultural Affiliation'].'<br>';?></td>
							
						</tr>
					</table>
					<?php
			}
				}
		}

			else {
			echo mysql_error();
			}
	}	else {
			echo '<br><br><br>Must be a preset value';
		}
}
?>
</div>


<!-- Artifacts Search -->
<div class="userinput3">
<form class="SearchBox" action="index.php" method="POST">
	<h4>Artifacts: </h4>
	<input type="text" name="search_artifacts"><br><br>
	<input type="submit" value="Search">	
</form>
</div>

<div class="result">
<?php
	if (isset($_POST['search_artifacts'])) {
		$search_artifacts = $_POST['search_artifacts'];
	if (!empty($search_artifacts)) {
		
		if (strlen($search_artifacts)>=4) {
		
		
			$query = "SELECT * FROM springcreek WHERE Artifacts LIKE '%".mysql_real_escape_string($search_artifacts)."%'";
			$query_run = mysql_query($query);
			$query_num_rows = mysql_num_rows($query_run);
			
			if ($query_num_rows>=1) {
				echo '<br><h4>'.$query_num_rows.' out of 137 sites have "'.$search_artifacts.'" as artifact:</h4>';
				while ($query_row= mysql_fetch_assoc($query_run)) 
				{?>
					<table style="width: 100%; text-align: center;">
    					<tr>
        					<th width="60px">Site</th>
							<th width="100px">Site Type</th>
							<th width="40px">ID</th>
							<th width="50px">Area</th>
							<th width="50px">Perimeter</th>
							<th width="50px">Acres</th>
							<th width="70px">Date Recorded</th>
							<th width="30px">Confidence</th>
							<th width="40px">Boundary Complete</th>
							<th width="40px">Linear</th>
							<th width="40px">Zone</th>
							<th width="100px">Recorder</th>
							<th width="40px">Collected</th>
							<th width="100px">Artifacts</th>
							<th width="40px">Diagnostic</th>
							<th width="100px">Cultural Affiliation</th>
							
						</tr>
						<tr>
							<td width="60px"><?php echo '<center>'.$query_row['Site'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Site Type'].'<br>'; ?></td>
							<td width="40px"><?php echo '<center>'.$query_row['ID'].'<br>'; ?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Area'].'<br>';?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Perimeter'].'<br>';?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Acres'].'<br>';?></td>
							<td width="70px"><?php echo '<center>'.$query_row['Date'].'<br>';?></td>
							<td width="30px"><?php echo '<center>'.$query_row['Confidence'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Boundary Complete'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Linear'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Zone'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Recorder'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Collected'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Artifacts'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Diagnostic'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Cultural Affiliation'].'<br>';?></td>
							
						</tr>
					</table>
					<?php
				}
			}	else {
				echo '<br><br><br>No result found for "'.$search_artifacts.'" as artifact.';
			}
		}	else {
			echo '<br><br><br>Your keyword must be 4 characters or more.';
		}
	}
	}
?>
</div>


<!-- Diagnostic Drop Down Menu -->
<div class="userinput4">
<form class="DiagnosticDD" action="index.php" method="GET">
	<h4>Diagnostic Sites:</h4>
	<select name="Diagnostic">
		<option value"Yes">Yes</option>
		<option value"No">No</option>
	</select><br><br>

	<input type="submit" value="Submit">	
</form>
</div>

<div class="result">
<?php
if (isset($_GET['Diagnostic'])&&!empty($_GET['Diagnostic'])) {
	
	$Diagnostic = ($_GET['Diagnostic']);

	if ($Diagnostic=='Yes'||$Diagnostic=='No') {
	
		// Setting Loop//
		$query = "SELECT * FROM springcreek WHERE `Diagnostic`='$Diagnostic' ORDER BY Site DESC";

		// Start Loop//
		if ($query_run = mysql_query($query)) {
			
			$query_num_rows = mysql_num_rows($query_run);

			if ($query_num_rows==NULL) {
				echo 'No results found.';
			}	else {
			
			echo '<br><h4>'.$query_num_rows.' out of 137 sites are "'.$Diagnostic.' - Diagnostic":</h4>';		
			while ($query_row = mysql_fetch_assoc($query_run)) {?>
				<table style="width: 100%; text-align: center;">
    					<tr>
        					<th width="60px">Site</th>
							<th width="100px">Site Type</th>
							<th width="40px">ID</th>
							<th width="50px">Area</th>
							<th width="50px">Perimeter</th>
							<th width="50px">Acres</th>
							<th width="70px">Date Recorded</th>
							<th width="30px">Confidence</th>
							<th width="40px">Boundary Complete</th>
							<th width="40px">Linear</th>
							<th width="40px">Zone</th>
							<th width="100px">Recorder</th>
							<th width="40px">Collected</th>
							<th width="100px">Artifacts</th>
							<th width="40px">Diagnostic</th>
							<th width="100px">Cultural Affiliation</th>
							
						</tr>
						<tr>
							<td width="60px"><?php echo '<center>'.$query_row['Site'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Site Type'].'<br>'; ?></td>
							<td width="40px"><?php echo '<center>'.$query_row['ID'].'<br>'; ?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Area'].'<br>';?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Perimeter'].'<br>';?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Acres'].'<br>';?></td>
							<td width="70px"><?php echo '<center>'.$query_row['Date'].'<br>';?></td>
							<td width="30px"><?php echo '<center>'.$query_row['Confidence'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Boundary Complete'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Linear'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Zone'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Recorder'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Collected'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Artifacts'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Diagnostic'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Cultural Affiliation'].'<br>';?></td>
							
						</tr>
					</table>
					<?php
			}
				}
		}

			else {
			echo mysql_error();
			}
	}	else {
			echo '<br><br><br>Must be a preset value';
		}
}
?>
</div>


<!-- Cultural Affiliation Search -->
<div class="userinput5">
<form class="SearchBox" action="index.php" method="POST">
	<h4>Cultural Affiliation: </h4>
	<input type="text" name="search_cultural"><br><br>
	<input type="submit" value="Search">	
</form>
</div>

<div class="result">
<?php
	if (isset($_POST['search_cultural'])) {
		$search_cultural = $_POST['search_cultural'];
	if (!empty($search_cultural)) {
		
		if (strlen($search_cultural)>=4) {
		
		
			$query = "SELECT * FROM springcreek WHERE `Cultural Affiliation` LIKE '%".mysql_real_escape_string($search_cultural)."%'";
			$query_run = mysql_query($query);
			$query_num_rows = mysql_num_rows($query_run);
			
			if ($query_num_rows>=1) {
				echo '<br><h4>'.$query_num_rows.' out of 137 sites have "'.$search_cultural.'" as Cultural Affiliation:</h4>';
				while ($query_row= mysql_fetch_assoc($query_run)) 
				{?>
					<table style="width: 100%; text-align: center;">
    					<tr>
        					<th width="60px">Site</th>
							<th width="100px">Site Type</th>
							<th width="40px">ID</th>
							<th width="50px">Area</th>
							<th width="50px">Perimeter</th>
							<th width="50px">Acres</th>
							<th width="70px">Date Recorded</th>
							<th width="30px">Confidence</th>
							<th width="40px">Boundary Complete</th>
							<th width="40px">Linear</th>
							<th width="40px">Zone</th>
							<th width="100px">Recorder</th>
							<th width="40px">Collected</th>
							<th width="100px">Artifacts</th>
							<th width="40px">Diagnostic</th>
							<th width="100px">Cultural Affiliation</th>
							
						</tr>
						<tr>
							<td width="60px"><?php echo '<center>'.$query_row['Site'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Site Type'].'<br>'; ?></td>
							<td width="40px"><?php echo '<center>'.$query_row['ID'].'<br>'; ?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Area'].'<br>';?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Perimeter'].'<br>';?></td>
							<td width="50px"><?php echo '<center>'.$query_row['Acres'].'<br>';?></td>
							<td width="70px"><?php echo '<center>'.$query_row['Date'].'<br>';?></td>
							<td width="30px"><?php echo '<center>'.$query_row['Confidence'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Boundary Complete'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Linear'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Zone'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Recorder'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Collected'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Artifacts'].'<br>';?></td>
							<td width="40px"><?php echo '<center>'.$query_row['Diagnostic'].'<br>';?></td>
							<td width="100px"><?php echo '<center>'.$query_row['Cultural Affiliation'].'<br>';?></td>
							
						</tr>
					</table>
					<?php
				}
			}	else {
				echo '<br><br><br>No result found for "'.$search_cultural.'" as Cultural Affiliation.';
			}
		}	else {
			echo '<br><br><br>Your keyword must be 4 characters or more.';
		}
	}
	}
?>
</div>


<!-- Top Button -->
<button onclick="topFunction()" id="myBtn" title="Back to top">Top</button>


</body>
</html>