<?php
// Get DB Connection Info //
require 'connect.inc.php';
?>

<form action="index.php" method="GET">
	Select a Site Type:<br><br>
	<select name="SiteType">
		<option value"Archaeological">Archaeological</option>
		<option value="Historical Archaeology" <?php if ($_GET['SiteType']=='Historical Archaeology') {echo "selected='selected'"; } ?> >Historical Archaeology</option>
		<option value"Historic | Historicalarchaeology">Historic | Historical Archaeology</option>
		<option value"Archaeological | Historical Archaeology">Archaeological | Historical Archaeology</option>
	</select><br><br>

	<input type="submit" value="Submit">	
</form>

<?php

if (isset($_GET['SiteType'])&&!empty($_GET['SiteType'])) {
	
	$SiteType = ($_GET['SiteType']);

	if ($SiteType=='Archaeological'||$SiteType=='Historical Archaeology'||$SiteType=='Historic | Historical Archaeology'||$SiteType=='Archaeological | Historical Archaeology') {
	
		// Setting Loop//
		$query = "SELECT * FROM springcreek WHERE `Site Type`='$SiteType' ORDER BY Site DESC";

		// Start Loop//
		if ($query_run = mysql_query($query)) {

			if (mysql_num_rows($query_run)==NULL) {
				echo 'No results found.';
			}	else {

			while ($query_row = mysql_fetch_assoc($query_run)) {
				$Site = $query_row['Site'];
				$Acres = $query_row['Acres'];
				$Linear = $query_row['Linear'];

			print "Site ".$Site.' is '.$Linear.' with '.$Acres.' acres.<br>';
			}
				}
		}

			else {
			echo mysql_error();
			}
	}	else {
			echo 'Must be a value';
		}
}
?>