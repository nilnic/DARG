<?php

$mysql_host = 'richott.fatcowmysql.com';
//$mysql_host = 'localhost';//
$mysql_user = 'nikita';
$mysql_pass = '500scraper';
$conn_error = 'Unable to Connect.';
$mysql_db = 'springcreek';

if (!@mysql_connect($mysql_host, $mysql_user, $mysql_pass) || !@mysql_select_db($mysql_db)) {
	die ($conn_error);
}  

?>