<html>
<head>
<title>Darg Educational</title>

	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta property="og:site_name" content="Dominquez Archaeological Research Group"/>
	<meta property="og:title" content="Educational"/>
	<meta property="og:description" content="Dominquez Archaeological Research Group (DARG) is a non-profit corporation established in 2003 as a consortium for anthropological and archaeological research, preservation and education in the Upper Colorado River ."/>
	<meta property="og:image" content="Image/DARG logo FB.png">
<!-- script type="text/javascript" src="http://use.typekit.com/oxt2noo.js"></script>
<script type="text/javascript">try{Typekit.load();}catch(e){}</script -->

<link rel="stylesheet" href="Style/styles-combined3.css">
<link rel="stylesheet" href="Style/modal-window.css">
<script type="text/javascript" src="js/jquery-1.6.1.min.js"></script>
<script type="text/javascript" src="JQuery/jquery-1.3.2.min.js"></script>
<!--Before and After js Example 2-->
<script type="text/javascript" src="js/jquery-ui-1.8.13.custom.min.js"></script>
<script type="text/javascript" src="js/jquery.beforeafter-1.4.js"></script>

<script type="text/javascript">
#beforeafterlink a:hover {
text-decoration: none; color: #666;}
}
</script>

<script type="text/javascript">

$(function(){
	$('#container').beforeAfter();

});
</script>
<script type="text/javascript" src="JQuery/jquery.ui-1.10.4.tabs.min.js"></script>
<script type="text/javascript" src="JQuery/modal-window.js"></script>
<link href="JQuery/jquery.ui.core.min.css" rel="stylesheet" type="text/css">
<link href="JQuery/jquery.ui.theme.min.css" rel="stylesheet" type="text/css">
<link href="JQuery/jquery.ui.tabs.min.css" rel="stylesheet" type="text/css">

<!--Tabs js-->
<script type="text/javascript">
$(function() {
	$( "#Tabs1" ).tabs({
		show:{effect: "fade", duration: 1000}
	}); 
});
</script>

<!-- script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.0/jquery.min.js"></script -->
<script type="text/javascript" src="JQuery/supersized.3.1.3.min.js"></script>

<!-- supersized js --><script type="text/javascript">
function fullScreen(theURL) {
window.open(theURL, '', 'fullscreen=yes, scrollbars=auto');
}
</script>
<!-- supersized params -->
<script type="text/javascript">
jQuery(function($){
$.supersized({

//Functionality
slideshow					:   1,//Slideshow on/off
autoplay					:	1,//Slideshow starts playing automatically
start_slide					:   0,//Start slide (0 is random)
random						: 	0,//Randomize slide order (Ignores start slide)
slide_interval				:   2000,//Length between transitions
transition					:   1, //0-None, 1-Fade, 2-Slide Top, 3-Slide Right, 4-Slide Bottom, 5-Slide Left, 6-Carousel Right, 7-Carousel Left
transition_speed			:	2000,//Speed of transition
new_window					:	1,//Image links open in new window/tab
pause_hover             	:   0,//Pause slideshow on hover
keyboard_nav				:   1,//Keyboard navigation on/off
performance					:	1,//0-Normal, 1-Hybrid speed/quality, 2-Optimizes image quality, 3-Optimizes transition speed // (Only works for Firefox/IE, not Webkit)
image_protect				:	1,//Disables image dragging and right click with Javascript
image_path					:	'Image/img/', //Default image path

//Size - Position
min_width					:   0,//Min width allowed (in pixels)
min_height					:   0,//Min height allowed (in pixels)
vertical_center				:   1,//Vertically center background
horizontal_center			:   1,//Horizontally center background
fit_portrait				:   0,//Portrait images will not exceed browser height
fit_landscape				:   0,//Landscape images will not exceed browser width

//Components
navigation					:   0,//Slideshow controls on/off
thumbnail_navigation    	:   0,//Thumbnail navigation
slide_counter           	:   0,//Display slide numbers
slide_captions          	:   0,//Slide caption (Pull from "title" in slides array)
slides 						:  
[//Slideshow Images
{image : 'Image/leanertipi.jpg', title : 'A \" leaner\" tipi, Moffat County, Colorado'},
{image : 'Image/5ME16710-panel2-detail.jpg', title : 'A petroglyph site in Mesa County, Colorado'},
{image : 'Image/ute-shoshone-pictos.jpg', title : 'Ute pictographs, Mesa County, Colorado'},
{image : 'Image/seibersteps2.jpg', title : 'Steps hewn in sandstone cliffs, Mesa County, Colorado'},
{image : 'Image/seibersteps.jpg', title : 'Steps hewn in sandstone cliffs, Mesa County, Colorado'},
{image : 'Image/Full_charcoal_panel.jpg', title : 'Full Charcoal Panel of Sweet Water Cave, Colorado'},
{image : 'Image/dendro1.jpg', title : 'Collecting a sample of juniper for tree ring dating at a wickiup site in Eagle County, Colorado. '},
{image : 'Image/5GF305_Panel_1_overview.jpg', title : 'Rock Art Panel 5GF.305 Overview, Colorado'}
]

});
    });
</script>



</head>

<body onload="initialize()">

<div id="masthead">
<img src="Image/DARG White Header.png" alt="Dominguez Anthropological Research Group" height="115px">
</div>
<div id="banner-wrap"></div>
<!-- div id="navwrap"></div>
<div id="slantedmenu" style="z-index: 8;">
<ul class="shadow">
<li><a href="file:///Users/ott/Documents/----DARG_masterfolder/-WEB/!NEWSITE/-NEW/"></a></li>
<li><a href="file:///Users/ott/Documents/----DARG_masterfolder/-WEB/!NEWSITE/-NEW/index.html">Home</a></li>
<li><a href="file:///Users/ott/Documents/----DARG_masterfolder/-WEB/!NEWSITE/-NEW/research.html">Research</a></li>
<li><a href="file:///Users/ott/Documents/----DARG_masterfolder/-WEB/!NEWSITE/-NEW/publications.html">Publications</a></li>
<li><a href="file:///Users/ott/Documents/----DARG_masterfolder/-WEB/!NEWSITE/-NEW/news.html">News &amp; Notes</a></li>
<li><a href="file:///Users/ott/Documents/----DARG_masterfolder/-WEB/!NEWSITE/-NEW/library/">Online Library</a></li>

<li><a href="file:///Users/ott/Documents/----DARG_masterfolder/-WEB/!NEWSITE/-NEW/purpose.html">Purpose</a></li>
<li><a href="file:///Users/ott/Documents/----DARG_masterfolder/-WEB/!NEWSITE/-NEW/people.html">People</a></li>
<li><a href="file:///Users/ott/Documents/----DARG_masterfolder/-WEB/!NEWSITE/-NEW/people.html">Partners</a></li>
<li><a href="contact.html">Contact</a></li>
<li><a href="search.html">Search</a></li>
</ul>
</div -->
<div id="homelink">
	<a href="index.php"><img src="Image/img/icones-png-theme-home-19.png" width="65" height="65" alt="Home"/></a>
<style>
	#homelink {font-weight: bold; text-align: center; margin-top: 5px; margin-bottom: -80px;}
</style>
</div>
<div id="Tabs1">
        <ul>
          <li><a href="#tabs-1" title="Obsidian">Obsidian</a></li>
          <li><a href="#tabs-3" title="Projects">Projects</a></li>
          <li><a href="#tabs-4" title="Presentations">Presentations</a></li>
          <li><a href="#tabs-5" title="Publications">Publications</a></li>
          <li><a href="#tabs-6" title="Gallery">Gallery</a></li>
          <li><a href="#tabs-7" title="Database">Database</a></li>       
        </ul>

<!--------------------- About Us Page (moved to index) ---------------------->        
<!--------------------- People Page (moved to index) ---------------------->    

<!--------------------- Obsidian Page ---------------------->    
<div id="tabs-1">
	<div class="TabHeader"></div>
	<center><strong>Obsidian Mapping:</strong> Compilation of recorded obsidian tools accross our area of studies. All coordinates are removed. Zoom is controlled.<br><br></center>
<?php include 'obsidian.php';?>

</div>
<!--------------------- Projects Page ---------------------->               
<div id="tabs-3">
          <center>
          <div class="Projects">
              <p>&nbsp;</p>
              <table width="93%" border="10" frame="void" rules="rows" summary="List of ongoing projects">
                <tbody>
                  <tr>
                    <th width="190" height="40" style="color: white" scope="col"><p>Active:</p></th>
                    <th width="120" bgcolor="#BFBDBD" style="text-align: center; font-size: 12px;" scope="col"><p>Status [2017]</p></th>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Archaeological Assessment of Independence Mountain Sites</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">In progress</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Archaeological Assessment of the Occurrence of Culturally Modified Bison Bone Elements in Northwest and West Central Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">In progress</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Archaeological Assessment of the Moore Site, 5MN863</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">In progress</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Ute Trails of the Southern Uncompahgre Plateau: Spring Creek Section</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">In progress</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Archaeological Assessment of the Monitor Mesa Wickiup Site, 5MN42</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">In progress</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Archaeological Assessment of the Lee Ranch Wickiup Site 5MN41</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">In progress</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Archaeological Assessments of the Wickiup Sites 5MN44 and 5MN65</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">In progress</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Data Retrieval from Eight Sites in the Hubbard Mesa OHV Open Area for the Colorado River Valley Field Office</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">In progress</td>
                  </tr>
                   <tr style="font-size: 12px">
                    <td style="color: white">Rock Art Database Project</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">In progress</td>
                  </tr>
                </tbody>
              </table>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <table width="93%" border="10" frame="void" rules="rows" summary="List of ongoing projects">
                <tbody>
                  <tr>
                    <th width="186" height="40" style="color: white" scope="col"><p>Completed:</p></th>
                    <th width="124" bgcolor="#BFBDBD" style="text-align: center" scope="col"><p>Report Date</p></th>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Archaeological Assessment of Tunnel Siding and Station, 5ME21489</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2016</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Archaeological Assessment of the Roan Creek Toll Road</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2016</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Rock Art of the Colorado River Valley Field Office: An Ancillary Study of the Ute Trails Project</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2016</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">USFS Inventory for the Pauline and Cathedral Timber Sales Project in Saguache County</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2016</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Documentation of Selected Wooden Features in Four Sites in the Colorado National Monument</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2016</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">An Archaeological Assessment of the Windger Flats Drift Fence (5ME14198)</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2016</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Archaeological Assessment of Two Ute Trails in Eagle County, Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2016</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Archaeological Assessment of Wickiup Sites 5ME470 and 5ME6674</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2016</td>
                  </tr>
                   <tr style="font-size: 12px">
                    <td style="color: white">A Reexamination of the Uncompahgre Complex: Taylor Site 5ME97</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2016</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Archaeological Assessment of the 5MN1519 (Grand Lodge) and 5MN10514 Wickiup Sites</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2016</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Cultural Resources Inventory of 128 Miles of Open Drains in Mesa County, Colorado, for Grand Valley Drainage District</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2015</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Documentation of Selected Ephemeral Wooden Features in Colorado National Monument</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2015</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Site Reevaluation and Test Excavations at 5MN3462, the Jeff Lick Stone Circles, for the Grand Mesa, Uncompahgre, and Gunnison National Forest</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2015</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Falls Creek Rockshelters Archaeological Assessment Project - Phase II</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2014</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Database Project: Internet Application of Colorado Tree-ring Information</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2014</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Radiocarbon Database Project (Continuation of C14 study)</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2014</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Cultural Resources Inventory of the 7N and Long Creek Mesa Landscape Restoration Project for the Grand Mesa, Uncompahgre, and Gunnison National Forest</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2014</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Cultural Resources Inventory of the Moore and Payne Mesa Landscape Restoration Project for the Grand Mesa, Uncompahgre, and Gunnison National Forest</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2014</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Archaeological Assessment of the Gunsight Pass Site: 5GA4251 Archaeoastronomy and Landscape Archaeology in Middle Park</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2013</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Ute Trails Project: Phase I Years 2010-2012 Reconnaissance Survey of Ute Trails on the Uncompahgre Plateau in Mesa County, Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2013</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">The Colorado Wickiup Project Phase VII: Documentation of Selected Ephemeral Wooden Feature Sites in Rocky Mountain National Park</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2013</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Cottonwood Cave (5MN519) Assessment Project</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2013</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Colorado Wickiup Project: Assessment of Four Decker Wickiup Sites</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2013</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Cultural Resources Reconnaissance for the Bocco Mountain Special Recreation Management Area in Eagle County</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2012</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">An Archaeological Assessment of the
					Colorow Gulch Wickiups (5RB2968)</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2012</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Cultural Resources Investigations for the Grizzly Ridge Sage Grouse Hydro-axe Treatment Areas in Montrose and Delta Counties</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2012</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">McClane Canyon Rock Shelter Excavation</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2012</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Colorado Wickiup Project: Phase VII - Rocky Mountain National Park</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2012</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Ute Trails Project: Blue Creek Drainage</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2012</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Colorado Radiocarbon Database Project: Phase IV Eastern Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2012</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Excelsior Station Assessment</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2012</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Reevaluation of Basketmaker II Material Culture from the Falls Creek Rockshelters Phase 2</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2012</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Glade Guard Station Rehabilitation</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2012</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Ute Rock Art Maps Study for BLM-NLCS</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2012</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Debeque Canyon Rock Art Documentation</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2012</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td height="31" style="color: white">The Lanuage of the Land Conference</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">7-9 Oct 2011</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Colorado Wickiup Project: Phase VI - Test Excavation of Black Canyon Ramada (5DT222) and Documentation of Four Additional Aboriginal Wooden Feature Sites In Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2011</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">CCA Devils Canyon Scavanger Hunt</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2011</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Colorado Wickiup Project: Archaeological Assessment of Pisgah Mountain Wickiup Village (5EA2740), Eagle County, Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2011</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Colorado Wickiup Project: Phase V - Test Excavation of Ute Hunters' Camp (5RB563) and Documentation of Five Additional Aboriginal Wooden Feature Sites in Rio Blanco County, Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2010</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Late Quaternary Alluvial Deposits and Geoarchaeology of Douglas Creek Within Canyon Pintado National Historic District, Rio Blanco County, Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2010</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Redcliff Assessment (5ME15398)</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2010</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">BLM &amp; Ute Tribes Ethnohistory Project</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2010</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Battlement Mesa (5GF1323) Test Excavations: Phase I</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2009</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Colorado Wickiup Project: Phase IV - Recordation, Re-evaluation and Assessment of Fourteen Aboriginal Wooden Feature Sites in the Yellow Creek Archaeological District and Documentation of Thirteen Additional Aboriginal Wooden Feature Sites In Garfield, Mesa, Moffat and Rio Blanco Counties, Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2009</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td style="color: white">Testing and Evaluation of The Bocco Mountain Bison Ceremonial Site(5EA2742), Eagle County, Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2009</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td height="31" style="color: white">Colorado Radiocarbon Database Project: Phase III Southwestern Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2007</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td height="31" style="color: white">Colorado Wickiup Project: Sand Wash Survey In Moffat County, Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2007</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td height="31" style="color: white">Colorado Wickiup Project: Phase III - Recordation and Re-evaluation of Twelve Aboriginal Wooden Structure Sites in Eagle, Garfield, Mesa, and Rio Blanco Counties, Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2006</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td height="31" style="color: white">Archaeological Assessment of Leonard Basin and Palmer Gulch Rock Art</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2006</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td height="31" style="color: white">Archaeological Assessment of Big Dominguez Canyon</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2006</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td height="31" style="color: white">Colorado Radiocarbon Database Project: Phase I West-Central Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2006</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td height="31" style="color: white">Colorado Wickiup Project: Phase II - Cultural Resources Class II Reconnaissance Inventory for the Gunnison Gulch Area of Mesa County, Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2005</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td height="31" style="color: white">Colorado Wickiup Project: Phase I - Context, Data Assessment and Strategic Planning</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2005</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td height="31" style="color: white">Archaeological Assessment of the Blue Hill ACEC</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2005</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td height="31" style="color: white">McHatten Reservoir Site Assessment</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2004</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td height="31" style="color: white">Billings Canyon Excavation</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2004</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td height="31" style="color: white">Bangs Canyon Survey</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2004</td>
                  </tr>
                  <tr style="font-size: 12px">
                    <td height="31" style="color: white">Colorado Wickiup Project: Archaeological Assessment of Rifle Wickiup Village (5GF308) in Garfield County, Colorado</td>
                    <td bgcolor="#BFBDBD" style="text-align: center">2003</td>
                  </tr>
                </tbody>
              </table>
              <p>&nbsp;</p>
            </div>
          </center>
	<div class="TabHeader"></div>
          <table width="450" height="845">
            <tbody>
              <tr>
                <td colspan="3" style="font-weight: bold; color: #EB8F00;">The Eagle Rock Shelter</td>
                <td width="214" rowspan="2"><div><img src="Image/Projects/The Eagle Rock Shelter.jpg" align="right" alt="Eagle Rock Shelter"></div></td>
              </tr>
              <tr>
                <td colspan="3" style="text-align: left">The Eagle Rock Shelter, Site 5DT813, located in Delta County, Colorado on BLM lands, was
				excavated between 2013 and 2016 under a federal grant administered by Delta, County. Rock art recorded by Patterson and Watchman in 2006 indicated the site had been occupied since the Paleo period. Excavations proved the site contained multiple occupational horizons that span the period from about 13,000 BP to 350 BP. Maize recovered from the site returned a radiocarbon assay between 2040 BP and 1910 BP.<br>
                <a href="eagle_rockpage.html">(More)</a></td>
              </tr>
              <tr>
                <td height="50" colspan="4"></td>
              </tr>
              <tr>
                <td colspan="3" style="font-weight: bold; color: #EB8F00;">Western Colorado Bison Project</td>
                <td width="214" rowspan="2"><div><img src="Image/Projects/2015 2016 Bison and others 772.jpg" align="right" alt="Colorado Wickiup Project"></div></td>
              </tr>
              <tr>
                <td colspan="3" style="text-align: left">Evidence of bison and aboriginal bison procurement in western and northwestern Colorado is extremely rare as is scientific documentation, examination, and radiometric dating of culturally modified bison bone elements, thereby making it nearly impossible to provide valid interpretations of the interrelationship of bison and prehistoric peoples in western and northwestern Colorado. DARG’s research endeavor is specifically dedicated to evaluating, dating, and assimilating the resultant data of known culturally modified bison faunal elements in western Colorado.<br>         <a href="https://drive.google.com/open?id=0B0lmg9-GJovASTFkTmxsenNSeDA" title="Western Colorado Bison Project" target="new">(Presentation)</a><br>
                <a href="360_gallery.html">(360&deg; Bison Skull)</a></td>
              </tr>
              <tr>
                <td height="50" colspan="4"></td>
              </tr>
              <tr>
                <td colspan="3" style="font-weight: bold; color: #EB8F00;">Archaeoastromomy Research</td>
                <td width="214" rowspan="2"><div><img src="Image/Projects/Archaeoastronomy photo.jpg" align="right" alt="Colorado Wickiup Project"></div></td>
              </tr>
              <tr>
                <td colspan="3" style="text-align: left">Archaeoastronomical sophistication is known to occur in prehistoric cultures in the new world and is being investigated at several architectural sites in western Colorado by DARG archaeologists.  Sites with stone rings have been documented that exhibit alignments representing solstice and equinox positions, and possibly stellar arrangements.  As well, regional rock art reflects apparent shamanic associations of the calendric features.<br>
                <a href="https://drive.google.com/file/d/0B0lmg9-GJovAVGtEOUhGT2luWDg/view?usp=sharing" title="Archaeoastronomy Research" target="new">(Presentation)</a></td>
              </tr>
              <tr>
                <td height="50" colspan="4"></td>
              </tr> 
              <tr>
                <td colspan="3" style="font-weight: bold; color: #EB8F00;">Colorado Wickiup Project</td>
                <td width="214" rowspan="2"><div><img src="Image/Projects/bigtmb-singwick.jpg" align="right" alt="Colorado Wickiup Project"></div></td>
              </tr>
              <tr>
                <td colspan="3" style="text-align: left">DARG's long-term project to document rapidly disappearing wickiups and other ephemeral, aboriginal wooden structures in the Colorado is enriching the archaeological and ethnohistorical record of the Northern Utes. <br>
                <a href="https://drive.google.com/file/d/0B0lmg9-GJovARk5nblNPVWxzRzA/view?usp=sharing" title="Colorado Wickiup Project" target="new">(Presentation)</a><br>
                <a href="cwp.html">(More)</a></td>
              </tr>
              <tr>
                <td height="50" colspan="4"></td>
              </tr>
              <tr>
                <td colspan="3" style="font-weight: bold; color: #EB8F00;">Prehistoric Archaeology</td>
                <td rowspan="2"><div><img src="Image/Projects/bigtmb-dig2.jpg" align="right" alt="Paleoindian and Early Archaic Studies"></div></td>
              </tr>
              <tr>
                <td colspan="3">A series of excavations as part of DARG's Paleoindian and early Archaic studies are uncovering new views of western Colorado's earliest human cultures, and new research projects are focusing on Basketmaker II sites in west central and southwestern Colorado.</td>
              </tr>
              <tr>
                <td height="50" colspan="4"></td>
              </tr>
              <tr>
                <td colspan="3" style="font-weight: bold; color: #EB8F00;">Ute Trails Project</td>
                <td rowspan="2"><div><img src="Image/Projects/bigtmb-ute-shoshone.jpg" align="right" alt="Ute Trails Project"></div></td>
              </tr>
              <tr>
                <td colspan="3">In 2010 DARG launched a long-range, landscape-scale project to integrate archaeological, ethnological and ethnohistorical data and perspectives for sites and locales associated with historic Ute trails throughout central and western Colorado.<br>
                <a href="https://drive.google.com/file/d/0B0lmg9-GJovAWnR5WURTaG5UVTg/view?usp=sharing" title="Ute Trails Project" target="new">(Presentation)</a></td>
              </tr>
              <tr>
                <td height="50" colspan="4"></td>
              </tr>
              <tr>
                <td colspan="3" style="font-weight: bold; color: #EB8F00;">Rock Art Studies</td>
                <td rowspan="2"><div><img src="Image/Projects/bigtmb-rockart.jpg" align="right" alt="Paleoindian and Early Archaic Studies"></div></td>
              </tr>
              <tr>
                <td colspan="3">Petroglyphs and pictographs are continually at risk from natural and man-made causes. DARG is developing an on-going rock art recording and database project to create "preservation quality" documentation for these irrereplaceable cultural resources.</td>
              </tr>
            </tbody>
          </table>
          <p>&nbsp;</p>
          <p>&nbsp; </p>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <div id="top">
			  <a href="#masthead"><img src="Image/img/xbtop.png.pagespeed.ic.Kq8iy_6Hhi.png" width="30" height="30" alt="Top"/></a>
		  </div>
</div>

<!--------------------- Presentations Page ---------------------->     
<div id="tabs-4">
          <div class="TabHeader"></div> 
	
   <!--List of Presentations--->
   <div style="margin-bottom: 20px; text-align: center">
	   <h5>Available Presentations:</h5><br>
   		<a href="#rockart_crvfo">Rock Art of The Colorado River Valley Field Office</a><br>
   		<a href="#ute_trails">Ute Trails Project</a><br>
   		<a href="#digital_media">High Resolution Rock Art Photography and Editing </a><br>
   		<a href="#bison_bone">Bison and Prehistoric Native American Hunters in Western Colorado</a><br>
   		<a href="#paleoclimate">Correlation of Aeolian, Alluvial and Lacustrine Deposits Related to Past Climates and Cultural Change</a><br>
   		<a href="#mcclane_rockshelter">Archaeological Investigations at the McClane Rockshelter (5GF741)</a><br>
   		<a href="#late_archaic_pithouses">Late Archaic Pithouses of the Upper Colorado River Drainage</a><br>
   		<a href="#wickiup">The Colorado Wickiup Project</a><br>
   		<a href="#cultural_inventory">Cultural Inventory in The Piceance</a><br>  
   		<a href="#archaeoastronomy">Gunsight 5GA4251: An Archaeoastronomy Site in Middle Park, Colorado</a><br>  
   </div> 
   
   <!--Presentations--->   	
    <div class="DBheader" id="rockart_crvfo">
       	Rock Art of the Colorado River Valley Field Office
    </div>   
    <div class="PPpicture">
    	<iframe src="https://drive.google.com/file/d/0B0lmg9-GJovAcmJmQ09tZVd1YmM/preview" width="640" height="480"></iframe> 
    </div>
    <div class="Presentation">
      <p>This was a Section 110 related project for the purpose of conducting a study of the rock art within the
administrative boundary of the Colorado River Valley Field Office (CRVFO), Bureau of Land Management.
Our thanks go to the CRVFO and Archaeologist Erin Leifeld who secured the funding for this project. This
study is ancillary to the Ute Trails Project, a research endeavor of Dominquez Archaeological Research
Group (DARG). The purposes of the study were to revisit and digitally photograph previously recorded
rock art panels and record any newly discovered sites encountered during the revisits.</p>
      <br>
      <br>
      <br> 
    </div>
    <div class="DBheader" id="ute_trails">
       	Ute Trails Project
    </div>   
    <div class="PPpicture">
    	<iframe src="https://drive.google.com/file/d/0B0lmg9-GJovAWnR5WURTaG5UVTg/preview" width="640" height="480"></iframe> 
    </div>
    <div class="Presentation">
      <p>The trails projects examine prehistoric and historic sites associated with aboriginal trail routes, with the intended results of providing tribal and agency cultural resource managers with landscape scale archaeological baseline data.<br>
      The importance of trails depends on the mobility of a society.  They are characteristically used for trade between resource differentiated regions, for seasonal movements, inter-group ceremonies, and sacred journeys.  Aboriginal hunter-gatherers for example have extensive seasonal movements for changing food resources, but their choice of foot or horse affected the ways and modifications of the routes used.  Important contrasts can be drawn between those created by aboriginal foot traffic and those utilized by horse traffic – especially in mountainous regions. 
	  </p>
      <br>
      <br>
      <br> 
    </div>
    <div class="DBheader" id="digital_media">
       	High Resolution Rock Art Photography and Editing
    </div>   
    <div class="PPpicture">
    	<iframe src="https://drive.google.com/file/d/0B0lmg9-GJovANy1OcTIwWVRmQlE/preview" width="640" height="480"></iframe> 
    </div>
    <div class="Presentation">
      <p>This presentation shows possible applications of high resolution photography to rock art preservation. It focuses on how to create high resolution photos, and then how to use them to trace or to remove vandalism from the panels. It also talks about 3d reconstructions of collapsed wickiups. 
	  </p>
      <br>
      <br>
      <br> 
    </div>
    <div class="DBheader" id="bison_bone">
       	Bison and Prehistoric Native American Hunters in Western Colorado
    </div>   
    <div class="PPpicture">
    	<iframe src="https://drive.google.com/file/d/0B0lmg9-GJovASTFkTmxsenNSeDA/preview" width="640" height="480"></iframe> 
    </div>
    <div class="Presentation">
      <p>Evidence of bison and aboriginal bison procurement in western and northwestern Colorado is extremely rare as is scientific documentation, examination, and radiometric dating of culturally modified bison bone elements, thereby making it nearly impossible to provide valid interpretations of the interrelationship of bison and prehistoric peoples in western and northwestern Colorado. DARG’s research endeavor is specifically dedicated to evaluating, dating, and assimilating the resultant data of known culturally modified bison faunal elements in western Colorado. 
	  </p>
      <br>
      <br>
      <br> 
    </div>
    <div class="DBheader" id="paleoclimate">
       	Correlation of Aeolian, Alluvial and Lacustrine Deposits Related to Past Climates and Cultural Change
    </div>   
    <div class="PPpicture">
    	<iframe src="https://drive.google.com/file/d/0B0lmg9-GJovAcDNCdUhkX3h1Znc/preview" width="640" height="480"></iframe> 
    </div>
    <div class="Presentation">
      <p>Past climate of western Colorado since 14,000 RCYBP varied from extreme drought to moderating conditions. Alluvial and aeolian deposits react to changing climates. Incision in alluvium and stabilization of aeolian deposits correspond to cool/wet conditions; alluvial deposition, aeolian deflation, and, in one period, dune formation correlate to warm/dry intervals. Subsistence and settlement patterns vary from large group size and low mobility in cooler intervals to small group size and high mobility in warmer intervals. The major droughts occurred 13,000 to 11,000, 9500 to 6500, 4000 to 2800, and 1000 to 600 RCYBP. Lake level data from Colorado, Wyoming and Utah, and PDSI (tree ring) data support the model. Identified droughts correspond to the Clovis drought, Paleoindian to Early Archaic and Middle Archaic to Late Archaic transitions, and organized warfare on the Plains. Middle Holocene and Late Holocene ameliorations correlate to house pits through the Rockies and BMII. 
	  </p>
      <br>
      <br>
      <br> 
    </div>
    <div class="DBheader" id="mcclane_rockshelter">
       	Archaeological Investigations at the McClane Rockshelter (5GF741)
    </div>   
    <div class="PPpicture">
    	<iframe src="https://drive.google.com/file/d/0B0lmg9-GJovATVJVVmxLWkpQUWs/preview" width="640" height="480"></iframe> 
    </div>
    <div class="Presentation">
      <p>The project entailed the excavation of 10.5 square meters within and on the perimeter of the overhang.  Cultural deposits ranging in age from about 4200 to 300 years ago were encountered, primarily in four cultural levels.  McKean Complex is represented in the two lowest stratigraphic units, which contained three occupation levels dating between ca. 4200-3000 BP.  
	  </p>
      <br>
      <br>
      <br> 
    </div>
    <div class="DBheader" id="late_archaic_pithouses">
       	Late Archaic Pithouses of the Upper Colorado River Drainage
    </div>   
    <div class="PPpicture">
    	<iframe src="https://drive.google.com/file/d/0B0lmg9-GJovASGMzNzVoaTNvRk0/preview" width="640" height="480"></iframe> 
    </div>
    <div class="Presentation">
      <p>This presentation discusses two pithouse structures found in the benchland area south of the Colorado River in the vicinity of Battlement Mesa Community and the town of De Beque. Both pit-structures exhibit similar morphology and are associated with the same type of distinctive artifacts.   
	  </p>
      <br>
      <br>
      <br> 
    </div>
    <div class="DBheader" id="wickiup">
       	The Colorado Wickiup Project
    </div>   
    <div class="PPpicture">
    	<iframe src="https://drive.google.com/file/d/0B0lmg9-GJovARk5nblNPVWxzRzA/preview" width="640" height="480"></iframe> 
    </div>
    <div class="Presentation">
      <p>The Colorado Wickiup Project (CWP) has been conducting a program of context development, data assessment, and comprehensive field documentation of aboriginal wooden feature sites in the state since 2004.   
	  </p>
      <br>
      <br>
      <br> 
    </div>
    <div class="DBheader" id="cultural_inventory">
       	Cultural Inventory in The Piceance
    </div>   
    <div class="PPpicture">
    	<iframe src="https://drive.google.com/file/d/0B0lmg9-GJovAOGpKc3l5ZDQxczA/preview" width="640" height="480"></iframe> 
    </div>
    <div class="Presentation">
      <p>For any inventory, archaeological visibility is a major concern.  Most of the diagnostic artifacts recovered from previously recorded sites in the vicinity of the project area are late Archaic or younger.  This is a result of visibility rather than prehistoric preference.  The fact remains that deposits older than about 3000 years old simply do not have good surface exposure.  Aeolian deposits older than 3000 years ago are exposed in rill cuts, at the edge of sharp topographic breaks, or in disturbances caused by construction.  Over broad surrounding areas, the sage-steppe is underlain by over a meter of aeolian sheet deposits and while deposition in pinyon/juniper forest is less than half that, usually the entire sequence of aeolian deposits is present.  Surface exposure of older deposits over the surface is otherwise restricted to small deflated areas, and then only the upper contact of the early to middle Holocene deposits are usually exposed.   
	  </p>
      <br>
      <br>
      <br> 
    </div>
    <div class="DBheader" id="archaeoastronomy">
       	Gunsight 5GA4251: An Archaeoastronomy Site in Middle Park, Colorado
    </div>   
    <div class="PPpicture">
    	<iframe src="https://drive.google.com/file/d/0B0lmg9-GJovAVGtEOUhGT2luWDg/preview" width="640" height="480"></iframe> 
    </div>
    <div class="Presentation">
      <p>Gunsight is a prehistoric stone ring site in Middle Park, Colorado consisting of 30 stone features divided into five localities (A—E).<br>  
	  From Medicine Wheels, we inherited: true circles, flattened circles, ellipses/ovals, and egg-shapes, all associated with astronomical observations.  At Gunsight we have combinations of shapes: oval, egg, lens, L, J, and irregular polygons.  A real mix and match scenario.  Is this a reflection of different techniques by different groups and/or at different times, for observation of different celestial bodies or events?   
	  </p>
      <br>
      <br>
      <br> 
    </div>                              
          <br>
          <br>
	      <div id="top">
			  <a href="#masthead"><img src="Image/img/xbtop.png.pagespeed.ic.Kq8iy_6Hhi.png" width="30" height="30" alt="Top"/></a>
		  </div>
</div>

<!--------------------- Publications Page ---------------------->               
<div id="tabs-5">
          <div class="TabHeader"></div>
          
          <p><em style="font-size: 12px; margin-left: 20px;">Note: Download files require Adobe Acrobat Reader; available <a href="http://www.adobe.com/products/acrobat/readstep2.html" target="_blank">here</a>.</em></p>
          <div class="Publications1">
            <table>
              <tbody>
                <tr>
                  <td height="0" colspan="4"></td>
                </tr>
                <tr>
                  <td rowspan="4"><div>
                    <p><img src="Image/Publications/Cottonwood Cave_tmb.jpg" alt="The Bocco Mountain Bison Ceremonial Site"></p>
                  </div></td>
                  <td colspan="4" style="text-align: left; color: #EB8F00;"><strong>Cottonwood Cave (5MN519) Assessment Project. Montrose County, Colorado</strong></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left"></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Prepared by Carole L. Graham and Sally J. Cole. Contributions by Karen A. Adams and David Hencmann. Compiled by Michael S. Berry</td>
                </tr>
                <tr>
                  <td><a href="cottonwood_abstract.html" onclick="$(this).modal({width:833, height:850}).open(); return false;"><strong>Abstract &amp; Download &gt;</strong></a></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td height="52" colspan="4"></td>
         		</tr>
                <tr>
                  <td rowspan="4"><div>
                    <p><img src="Image/Publications/Piceance_Ethno_tmb.jpg" alt="The Bocco Mountain Bison Ceremonial Site"></p>
                  </div></td>
                  <td colspan="4" style="text-align: left; color: #EB8F00;"><strong>Ethnographic Landscape Study Northwest Piceance Creek Basin Part I</strong></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left"></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Prepared by Carl E. Conner, Michael Berry, Nicky Pham, Masha Ryabkova, Jessica Yaquinto and Richard Ott with geomorphology sections derived from documents by James C. Miller, and the rock art introduction by Sally Cole</td>
                </tr>
                <tr>
                  <td><a href="piceance_ethno_abstract.html" onclick="$(this).modal({width:833, height:850}).open(); return false;"><strong>Abstract &amp; Download &gt;</strong></a></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td height="45" colspan="4"></td>
         		</tr>
                <tr>
                  <td rowspan="4"><div>
                    <p><img src="Image/Publications/fallscreekcover_tmb.jpg" alt="The Bocco Mountain Bison Ceremonial Site"></p>
                  </div></td>
                  <td colspan="4" style="text-align: left; color: #EB8F00;"><strong>Falls Creek Rockshelters Archaeological Assessment Project Phase II</strong></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left"></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Prepared by Karen R. Adams, Michael Berry, Mona Charles, Sally Cole, Phil R. Gieb, Carole L. Graham, Kristina Horton, Edward A. Jolie, Cerisa R. Reynolds, M. Steven Shackley, and Laurie D. Webster. Compiled by Carl Conner</td>
                </tr>
                <tr>
                  <td><a href="fallscreek_abstract.html" onclick="$(this).modal({width:833, height:850}).open(); return false;"><strong>Abstract &amp; Download &gt;</strong></a></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td height="56" colspan="4"></td>
         		</tr>
                <tr>
                  <td rowspan="4"><div><img src="Image/Publications/mcclane_tmb.jpg" alt="The Bocco Mountain Bison Ceremonial Site"></div></td>
                  <td colspan="4" style="text-align: left; color: #EB8F00;"><strong>Archaeological Investigations at the McClane Rockshelter 5GF741 Garfield County, Colorado</strong></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left"></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Michael Berry, Carl E. Conner, and James C. Miller</td>
                </tr>
                <tr>
                  <td><a href="mcclane_abstract.html" onclick="$(this).modal({width:833, height:850}).open(); return false;"><strong>Abstract &amp; Download &gt;</strong></a></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td height="60" colspan="4"></td>
                </tr>
                <tr>
                  <td rowspan="4"><p><img src="Image/Publications/ute_ethno_tmb.jpg" alt="Perspectives On Ute Ethnohistory in West Central Colorado"></p></td>
                  <td colspan="4" style="text-align: left; color: #EB8F00;"><strong>Perspectives On Ute Ethnohistory in West Central Colorado</strong></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Prepared for the Ute Tribes-BLM Ute Ehnohistory Project</td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Richard Ott, Betsy Chapoose, Clifford Duncan, and Terry G. Knight Sr.</td>
                </tr>
                <tr>
                  <td height="19"><a href="ute_ethno_abstract.html" onclick="$(this).modal({width:833, height:850}).open(); return false;"><strong>Abstract &amp; Download &gt;</strong></a></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td height="40" colspan="4"></td>
                </tr>
                <tr>
                  <td rowspan="4"><p><img src="Image/Publications/CNM 2016 Report_tmb.jpg" alt="2016 Documentation of Selected Ephemeral Wooden Features in Colorado National Monument, Mesa County, Colorado"></p></td>
                  <td colspan="4" style="text-align: left; color: #EB8F00;"><strong>2016 Documentation of Selected Ephemeral Wooden Features in
				  Colorado National Monument, Mesa County, Colorado</strong></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Compiled for National Park Service, Colorado National Monument and the Colorado National Monument Association</td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Prepared by Carl Conner, Masha Conner, Barbara Davenport, and Nicole Inman in association with the Ute Trails of Colorado Project.</td>
                </tr>
                <tr>
                  <td height="19"><a href="selected_ephemeral_wf.html" onclick="$(this).modal({width:833, height:850}).open(); return false;"><strong>Abstract &amp; Download &gt;</strong></a></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td height="40" colspan="4"></td>
                </tr>
                <tr>
                  <td rowspan="4"><p><img src="Image/Publications/Gunsight Final REPORT_Web_Version_tmb.jpg" alt="An Archaeological Assessment Of The Gunsight Pass Site: 5GA4251 Archaeoastronomy And Landscape Archaeology in Middle Park, Grand County, Colorado"></p></td>
                  <td colspan="4" style="text-align: left; color: #EB8F00;"><strong>An Archaeological Assessment Of The Gunsight Pass Site: 5GA4251 Archaeoastronomy And Landscape Archaeology in Middle Park, Grand County, Colorado</strong></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Completed for The Colorado Historical Society. State Historical Fund Project No. 2013-AS-003.</td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Prepared by Brian O'Neil and Cheryl A. Harrison with contributions by Holly Shelton and Nicole Inman. Michael S. Berry as the Principal Investigator.</td>
                </tr>
                <tr>
                  <td height="19"><a href="gunsight_abstract.html" onclick="$(this).modal({width:833, height:850}).open(); return false;"><strong>Abstract &amp; Download &gt;</strong></a></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td colspan="4"></td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="Publications2">
            <table>
              <tbody>
                <tr>
                  <td height="0" colspan="4"></td>
                </tr>
                <tr>
                  <td rowspan="4"><img src="Image/Publications/CWP_1_tmb.jpg" alt="The Colorado Wickiup Project Volume I"></td>
                  <td colspan="4" style="text-align: left; color: #EB8F00;"><strong>The Colorado Wickiup Project Volume I &amp; II</strong></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Context, Data Assessment and Strategic Planning</td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Curtis Martin, Richard Ott and Nicole Darnell</td>
                </tr>
                <tr>
                  <td><a href="cwp_1_abstract.html" onclick="$(this).modal({width:833, height:850}).open(); return false;"><strong>Abstract &amp; Download &gt;</strong></a></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td height="72" colspan="4"></td>
                </tr>
                <tr>
                  <td rowspan="4"><img src="Image/Publications/CWP_3_tmb.jpg" alt="The Colorado Wickiup Project Volume III"></td>
                  <td colspan="4" style="text-align: left; color: #EB8F00;"><strong>The Colorado Wickiup Project Volume III</strong></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Recordation and Re-evaluation of Twelve Aboriginal Wooden Structure Sites in Eagle, Garfield, Mesa, and Rio Blanco Counties, Colorado</td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Curtis Martin, Richard Ott and Nicole Darnell</td>
                </tr>
                <tr>
                  <td><a href="cwp_3_abstract.html" onclick="$(this).modal({width:833, height:850}).open(); return false;"><strong>Abstract &amp; Download &gt;</strong></a></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td height="64" colspan="4"></td>
                </tr>
                <tr>
                  <td rowspan="4"><img src="Image/Publications/CWP_4_tmb.jpg" alt="The Colorado Wickiup Project Volume IV"></td>
                  <td colspan="4"><strong style="color: #EB8F00">The Colorado Wickiup Project Volume IV</strong></td>
                </tr>
                
                <tr>
                  <td colspan="4">Recordation and Re-evaluation of Twenty-seven Aboriginal Wooden Feature Sites in Garfield, Mesa, Moffat and Rio Blanco Counties, Colorado</td>
                </tr>
                <tr>
                  <td colspan="4">Curtis Martin, Richard Ott, Nicole Darnell and James C. Miller</td>
                </tr>
                <tr>
                  <td><a href="cwp_4_abstract.html" onclick="$(this).modal({width:833, height:850}).open(); return false;"><strong>Abstract &amp; Download &gt;</strong></a></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td height="60" colspan="4"></td>
                </tr>
                <tr>
                  <td rowspan="4"><img src="Image/Publications/CWP_5_tmb.jpg" alt="The Colorado Wickiup Project Volume V"></td>
                  <td colspan="4" style="text-align: left; color: #EB8F00;"><strong>The Colorado Wickiup Project Volume V</strong></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Test Excavation of The Ute Hunters' Camp (5RB563) and the Documentation of Five Additional Aboriginal Wooden Feature Sites in Rio Blanco County, Colorado</td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Curtis Martin, Michael J. Brown and Carl E. Conner</td>
                </tr>
                <tr>
                  <td><a href="cwp_5_abstract.html" onclick="$(this).modal({width:833, height:850}).open(); return false;"><strong>Abstract &amp; Download &gt;</strong></a></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td height="60" colspan="4"></td>
                </tr>
                <tr>
                  <td rowspan="4"><img src="Image/Publications/CWP_6_tmb.jpg" alt="The Colorado Wickiup Project Volume VI"></td>
                  <td colspan="4" style="text-align: left; color: #EB8F00;"><strong>The Colorado Wickiup Project Volume VI</strong></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Test Excavation of The Black Canyon Ramada (5DT222) and the Documentation of Four Additional Premier Aboriginal Wooden Feature Sites in Colorado 
                  </td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Curtis Martin, Michael J. Brown and John E. Lindstrom</td>
                </tr>
                <tr>
                  <td><a href="cwp_6_abstract.html" onclick="$(this).modal({width:833, height:850}).open(); return false;"><strong>Abstract &amp; Download &gt;</strong></a></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td height="75" colspan="4"></td>
                </tr>
                <tr>
                  <td rowspan="4"><img src="Image/Publications/CWP_7_tmb.jpg" alt="The Colorado Wickiup Project Volume VII"></td>
                  <td colspan="4" style="text-align: left; color: #EB8F00;"><strong>The Colorado Wickiup Project Volume VII</strong></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Documentation of Selected Ephemeral Wooden Feature Sites in Rocky Mountain National Parl, Colorado 
                  </td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Curtis Martin, John E. Lindstrom and Holly Shelton</td>
                </tr>
                <tr>
                  <td><a href="cwp_7_abstract.html" onclick="$(this).modal({width:833, height:850}).open(); return false;"><strong>Abstract &amp; Download &gt;</strong></a></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td height="75" colspan="4"></td>
                </tr>
                <tr>
                  <td rowspan="4"><img src="Image/Publications/Eagle rock shelter_Redacted_tmb.jpg" alt="The Eagle Rock Shelter"></td>
                  <td colspan="4" style="text-align: left; color: #EB8F00;"><strong>Geomorphological Profile at Eagle Rock Shelter<br>
				  Site 5DT813, Delta County, Colorado</strong></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Completed for Dudley Gardner, Western Wyoming Community College<br>
				  Rock Springs, Wyoming 
                  </td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: left">Prepared by Stephanie Dudash and Abbie L. Harrison. Jonathon C. Horn as the Principal Investigator.
               </td>
                </tr>
                <tr>
                  <td><a href="eagle_rock.html" onclick="$(this).modal({width:833, height:850}).open(); return false;"><strong>Abstract &amp; Download &gt;</strong></a></td>
                  <td></td>
                  <td></td>
                </tr>
                
              </tbody>
            </table> 
          </div>
           <br>
          <br>
          <br>
		  <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
		  <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
		  <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
		  <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
   		  <br>
          <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
          <br>
   		  <br>
          <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
          <br>
   		  <br>
          <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
          <br>
   		  <br>
          <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <br>
       	  <center>
       	  Please Scroll To The Top After Clicking on "Abstract & Download"
	</center>
       	  <br>
       	  <div id="top">
			  <a href="#masthead"><img src="Image/img/xbtop.png.pagespeed.ic.Kq8iy_6Hhi.png" width="30" height="30" alt="Top"/></a>
		  </div>
</div>
      
<!--------------------- Gallery Page ---------------------->        
<div id="tabs-6">
          <div class="TabHeader"></div>

<!-- INTRO TEXT -->
<div class="gallery_buttons" style="margin-left: 220px; margin-bottom: 10px;">
	<a href="rockart_gallery.html" title="Rock Art" target="_parent"><figure><img src="Image/img/rock-art-button-large-version-5.png" width="125" height="35" alt="Rock Arts" style="padding: 15px;"/></figure></a></div>
<div class="gallery_buttons" style="text-align: center; margin-bottom: 10px; margin-top: -78px;">	
	<a href="wickiup_gallery.html" title="Wickiup" target="_parent"><figure><img src="Image/img/wickiup-button-large-version-2.png" width="125" height="35" alt="Wickiups" style="padding: 15px;"/></figure></a></div>
<div class="gallery_buttons" style="margin-left: 600px; margin-bottom: 10px; margin-top: -78px;">	
	<a href="360_gallery.html" title="3D Model" target="_parent"><figure><img src="Image/img/360-button.png" width="125" height="35" alt="360 Models" style="padding: 15px;"/></figure></a></div>

<div style="position: relative; top: 0px; margin-left: 50px; right: auto; width: 850px; text-align: center; font-family: 'lucida grande',sans-serif; color=#4f4b4b; font-size: 1em; line-height: 130%;">

<p><b>
A demonstration of ultra-high-resolution digital photography and advanced image processing for rock art documentation.
	</b></p><br><br>
</div>

<!-- Example 1 -->

<div style="position: relative; margin-left: 100px; margin-top: 10px; width: 325px; height: 150px; background-color: #eee; padding: 15px; font-family: 'lucida grande',sans-serif; color=#4f4b4b; font-size: .85em; line-height: 130%;">
<b>EXAMPLE 1:</b> <a href="#Example_1">[ See below ]</a><br>
Ultra high resolution (gigapixel) composite of petroglyph at 5ME16710, detail view of Panel 2.<br><br>
Image/pixel dimensions: 10514 x 21736 px, 228Mp<br>
File size/format: 580 Mb, TIFF (LZW)<br><br>

(For best results, maximize browser window.<br>
Click viewer HELP button for navigation tips.)
</div>

<!-- Example 2 -->

<div style="margin-top: -180px; margin-left: 500px; width: 325px; height: 150px; background-color: #eee; padding: 15px; font-family: 'lucida grande',sans-serif; color=#4f4b4b; font-size: .85em; line-height: 130%;">

<b>EXAMPLE 2:</b> <a href="#Example_2">[ See below ]</a><br>
Image enhancement using correlation stretching (Dstretch) of pictograph at 5ME16710, detail view of Panel 3.<br><br>

Image/pixel dimensions: 1728 x 1152 px<br>
<br>
(For best results, maximize browser window.)

</div>
<!-- Giga Pan Example 1 -->
<a id="Example_1"></a>
<div style="position: relative; top: 10px; padding: 0 50px;">
	<iframe src="http://www.gigapan.org/media/gigapans/78861/snapshots/218062,218061,218060/iframe/flash.html?height=1400" frameborder="0" height="1000" scrolling="no" width="100%"></iframe>
</div>      
<!-- Before and After Example 2 -->
<a id="Example_2"></a>

<div style="position: relative; top: -20px; padding: 0 5px; margin-left: 50px;">

<div id="container">
 <div><img alt="before" src="Image/Gallery_Example/5ME16710-Panel3-figure1-noDstretch.jpg" width="859" height="556" /></div>
 <div><img alt="after" src="Image/Gallery_Example/5ME16710-Panel3-figure1-yesDstretch.jpg" width="859" height="556" /></div>
</div>
	<p style="text-align: center; margin-top: 20px; margin-left: -30px;"><a href="dstretch.html">More D-Stretch Examples</a></p>
</div>
<div id="top">
	<a href="#masthead"><img src="Image/img/xbtop.png.pagespeed.ic.Kq8iy_6Hhi.png" width="30" height="30" alt="Top"/></a>
</div>
</div>   
       
<!--------------------- Database Page ---------------------->          
<div id="tabs-7">
  <div class="TabHeader"></div> 
    <div class="DBheader">
       	Piceance Landscape Database Project
    </div>
    <div class="Database">
      <p>DARG initiated the Piceance Landscape Database Project in 2016 in cooperation with the Bureau of Land Management to provide a regional overview of historic and prehistoric Native American land use. It is Part I of an Ethnographic Landscape Study of the Northwest Piceance Creek Basin, an area that was an essential portion of the traditional Ute homeland during the historic period. This area has importance for other tribal groups as well; however, this study’s focus is on the Utes and how they see themselves as connected to this landscape.</p>
      <p>&nbsp;</p>
      <p>The project comprises over 2700 sites within the Northwest Piceance boundary. Majority of the sites have components that are prehistoric with many are historic and paleontological, or various combination of the three. </p>
      <br>
       	<td><a href="Database/Piceance Landscape Study/Piceance Basin Landscape Study.html" target="_blank"><strong>Online Database &amp; Flowcharts &gt;</strong></a></td> 
    </div>
       
    <div class="DBpicture">
    <img src="Database/Piceance Landscape Study/Cover.jpg" width="200" height="240" alt=""> </div>
          <br>
          <br>
          <br>
          <br>
		  <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
                  
    <div class="DBheader">
       	Mesa County Ute Trails Database Project
    </div>
    <div class="Database">
      <p>DARG pursued this project, entitled Ute Trails of Mesa County, for the purpose of conducting a landscape-scale, multi-disciplinary study of two sections of the historic/prehistoric Ute Trails in Mesa County Colorado.</p>
      <p>&nbsp;</p>
      <p>This study integrates archaeological, ethnohistoric and contemporary Native American perspectives. The purposes of the study were to conduct database work, fieldwork school, Ute consultation, rock art documentation, field survey of sites, analysis and completion of the final report and public outreach and information sharing.  This included the identification of suspected prehistoric and historic trails or travel routes, the investigation and recording of the general distribution of associated cultural resources, and the evaluation of the significance of the cultural resources for inclusion on the National Register of Historic Places (NRHP). </p>
      <br>
       	<td><a href="http://dargnet.org/utetrails/index.html" target="_blank"><strong>Online Database (Password Required) &gt;</strong></a></td> 
    </div>
         
    <div class="DBpicture">
    <img src="Database/Mesa County Landscape Study_files/Cover.jpg" width="200" height="240" alt=""> </div>     
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
		  <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          
    <div class="DBheader">
       	Ute Trails Database Project
    </div>
   	<div class="Database">
      <p>DARG conducted a study entitled Ute Trails of Eagle County that included segments of two aboriginal trail systems within the Colorado River corridor. Centrally located in the Northern Utes' aboriginal territory, the two selected trail segments are part of the Sawatch Mountains system (Pisgah Mountain Section, ~9.0 miles) and White River Plateau system (Dotsero Section, ~2.75 miles). These segments offer rich and varied sources of archaeological information, and are historically significant to today's living descendants of the Utes that traveled them.</p>
      <p>&nbsp;</p>
      <p>A total of 2500 acres in two discrete parcels and centered on two suspected Ute Trails was included in the reconnaissance survey for cultural resources. Participants in the inventory of the Pisgah Mountain Section included PAAC members and members of the History Colorado SHF staff. Overall 33 sites and 71 isolated finds were identified with the present study. </p>
      <br>
       	<td><a href="http://dargnet.org/utetrails/index.html" target="_blank"><strong>Online Database (Password Required) &gt;</strong></a></td> 
    </div> 
   	  
   	<div class="DBpicture">
    <img src="Database/Ute Trails Project_files/Ute_Trails_Eagle_REPORT cc.jpg" width="200" height="240" alt=""> </div>    
    	  <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
		  <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
    <div class="DBheader" id="RCdatabase">
       	Colorado Radiocarbon Database
    </div>
   	<div class="Database">
      <p>DARG's comprehensive, multi-year project to compile radiocarbon dates recorded in legacy cultural resource management reports and other documents from archaeological sites throughout Colorado has compiled 3430 radiocarbon dates from 953 archaeological sites in Colorado. This database is accessible through the History Colorado Compass web site. It is password protected because it contains location data that could compromise site security. </p>
      <p>&nbsp;</p>
      <p>DARG also created a public radiocarbon database for Colorado, Utah, Arizona and New Mexico. It displays Google maps with limited zoom capabilities and does not show UTMs or latitude/longitude coordinates.  It provides researchers with a regional temporal resource without compromising site security. The database currently contains 7332 dates from 1845 sites and is updated as new data become available. </p>
      <br>
       	<td><a href="http://dargnet.org/net/RCPublic/" target="_blank"><strong>Public Online Database &gt;</strong></a></td> 
    </div> 
   	  
   	<div class="DBpicture">
    <img src="Database/Colorado Radiocarbon/bigtmb-profile.jpg" width="230" height="164" alt=""> </div>    
    	  <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
		  <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>   
    <div class="DBheader" id="RCdatabase">
       	Colorado Tree-Ring Database
    </div>
   	<div class="Database">
      <p>DARG's comprehensive, multi-year project to compile tree-ring dates from archaeological sites throughout Colorado has compiled 14,560  tree-ring dates from 409 archaeological sites in Colorado. This database is accessible through the History Colorado Compass web site. It is password protected because it contains location data that could compromise site security. </p>
      <p>&nbsp;</p>
      <p>DARG also created a public tree-ring database for Colorado, Utah, Arizona and New Mexico. It displays Google maps with limited zoom capabilities and does not show UTMs or latitude/longitude coordinates.  It provides researchers with a regional temporal resource without compromising site security. The database currently contains 34,175 dates from 1380 sites and is updated as new data become available. </p>
      <br>
       	<td><a href="http://dargnet.org/net/TRPublic/" target="_blank"><strong>Public Online Database &gt;</strong></a></td> 
    </div> 
   	  
   	<div class="DBpicture">
    <img src="Database/Tree Ring/dendro1.jpg" width="230" height="164" alt=""> </div>    
    	  <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
		  <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>
          <br>          
          <div id="top">
			  <a href="#masthead"><img src="Image/img/xbtop.png.pagespeed.ic.Kq8iy_6Hhi.png" width="30" height="30" alt="Top"/></a>
		  </div>
</div> 
     
<!--------------------- Contact Page (moved to index) ---------------------->          

</div>
<!-- ******* END Tab ************************************************************************************************** -->



<!--Thumbnail Navigation-->
<div id="prevthumb"></div> <div id="nextthumb"></div>
<!--Control Bar-->
<div id="controls-wrapperhidden">

<!-- FOOTER -->
<div id="footer">Dominquez Archaeological Research Group (DARG)
is a division of Dominquez Archaeological Research Group, Inc., a 501(c)(3) non-profit corporation.  •
P.O. Box 3543 • Grand Junction, CO  81502 • Phone: 970-245-7868 • darg.colorado@gmail.com</div>
<div id="footer-bg"></div>

<!-- END FOOTER -->
<div id="controls">
<!--Slide captions displayed here-->
<div id="slidecaption"></div>


</div>
</div>

</body></html>