<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta property="og:site_name" content="Dominquez Archaeological Research Group"/>
	<meta property="og:title" content="Homepage"/>
	<meta property="og:description" content="Dominquez Archaeological Research Group (DARG) is a non-profit corporation established in 2003 as a consortium for anthropological and archaeological research, preservation and education in the Upper Colorado River ."/>
	<meta property="og:image" content="Image/DARG_logo_clear_back_large.png"/>
	<title>DARG Homepage</title>
<!--

Template 2084 Zipper

http://www.tooplate.com/view/2084-zipper

-->
    <!-- load stylesheets -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400">  <!-- Google web font "Open Sans" -->
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">                <!-- Font Awesome -->
    <link rel="stylesheet" href="css/bootstrap.min.css">                                      <!-- Bootstrap style -->
    <link rel="stylesheet" href="css/tooplate-style.css">                                   <!-- Templatemo style -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
          <![endif]-->
</head>

    <body>

        <div class="container-fluid">
            <!-- Navigation -->        
            <div class="tm-nav">
                <nav class="navbar">

                    <button class="navbar-toggler hidden-md-up" type="button" data-toggle="collapse" data-target="#tmNavbar"></button> <!-- &#9776; ☰ -->
                    <div class="collapse navbar-toggleable-sm text-xs-center tm-navbar" id="tmNavbar">
                        <ul class="nav navbar-nav">
                            <li class="nav-item active selected">
                                <a class="nav-link current" href="#home">Home <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#about">About</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#people">People</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#partners">Partners</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#news">News</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#educational">Educational</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#contact">Contact</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            
            <section class="tm-section tm-section-home tm-flex-center" id="home">                
                
                <div class="tm-hero">
                    <div class="row">
                        <div class="col-lg-12">                           
                            <img src="Image/DARG White Header Logo.png" alt="Dominguez Anthropological Research Group" height="170px" width="auto">                         
                        </div>                    
                    </div>
                </div>                
            </section>
            
            <!-- Section 2 -->
            <section class="tm-section tm-section-about" id="about">

                <div class="tm-page-content-width">
                    <div class="tm-bg-black-translucent tm-content-box tm-content-box tm-flex-center">
                        <div class="tm-content-box-inner">
                            <h2 class="tm-section-title">About Us</h2>
                            <p style="font-size: 14px">Dominquez Archaeological Research Group (DARG) is the operational division of Dominquez Archaeological Research Group, Inc., a 501(c)(3) non-profit corporation established in 2003 as a consortium for anthropological and archaeological research, preservation and education in the Upper Colorado River Basin.</p>
          					<p style="font-size: 14px">DARG's mission is to provide an organizational and operational environment that facilitates:</p>
          				<ul id="ul1" style="font-size: 14px;">
            				<li>Professional excellence and the application of high standards in archaeological and anthropological research, preservation, and education.</li>
            				<br>
            				<li>Scientific rigor and the development and application of innovative research methods and advanced technology for data capture and information management in archaeology and anthropology.</li>
            				<br>
            				<li>Cooperative and collaborative approaches in cultural resources research, preservation, and education that integrate cross-boundary knowledge and expertise from diverse professional, institutional, and public sources.</li>
          				</ul>
							<p></p>
          					<p style="font-size: 14px">We function as a consortium of independent research associates and ad hoc research and technical advisors. Our operational focus is to coordinate research activities, raise and administer funding, and manage projects that advance our shared values and mission.</p>   
                        </div>                        
                    </div>                    
                </div>
                
            </section>
            
            <!-- Section 3 -->
            <section class="tm-section tm-section-people" id="people">

                <div class="tm-page-content-width">
                    <div class="tm-bg-black-translucent tm-content-box-right tm-content-box tm-flex-center">
                        <div class="tm-content-box-inner">
                            <h2 class="tm-section-title">People</h2>
                             <p style="font-size: 14px">DARG functions as a consortium of independent research associates and ad hoc technical advisors. Our operational focus is to coordinate research activities, raise and administer funding, and manage projects that advance our shared professional values and research goals.</p>
          
          <h5>Administrative Team</h5>
          
          <table width="400" border="0" align="center"  cellpadding="1">
            <tbody>
              <tr style="text-align: center">
                <td width="145" height="40" style="color: #eb8f00; text-align: right;"><strong>Carl E. Conner,&nbsp;&nbsp; President&nbsp;&nbsp; </strong></td>
                <td width="400" style="text-align: left">Archaeologist, Grand River Institute (founder and owner)</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Michael S. Berry,&nbsp;&nbsp; Research Director&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Archaeologist, Upper Colorado Region, Bureau of Reclamation (retired)</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Richard Ott, Project&nbsp;&nbsp; Coordinator/Grant&nbsp;&nbsp; Admin&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Information design and data visualization, independent consultant</td>
              </tr>
            </tbody>
          </table>
          
          <h5>Research Associate</h5>
          
          <table width="400" border="0" align="center" cellpadding="1">
            <tbody>
              <tr style="text-align: center">
                <td width="200" height="40" style="color: #eb8f00; text-align: right;"><strong>Michael Berry&nbsp;&nbsp;</strong></td>
                <td width="400" style="text-align: left">Principal Investigator, Colorado Radiocarbon Database Project, Falls Creek Project, DARG Database Design and Admin</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Carl Conner&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Principal Investigator, Ute Trails Project</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Masha Conner&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Biologist, Archaeologist, Graphic designer/Photographer</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Sally Crum&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Archaeologist, Grand Mesa National Forest, USDA-FS (retired)</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Barbara Davenport&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Archaeologist, Grand River Institute</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Courtney Groff&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Archaeologist, Geoarchaeologist, Grand River Institute</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Cheryl Harrison&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Archaeologist, BLM Glenwood Springs Field Office (retired)</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Nicole M. Inman&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">GIS/Graphics Specialist, Archaeologist</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Curtis W. Martin&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Principal Investigator, Colorado Wickiup Project</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Brian P. O'Neil&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Archaeologist, Archaeoastronomy</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Richard Ott&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Cultural landscapes, Ute ethnohistory, digital imaging, data visualization</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Thuong (Nicky)&nbsp; Pham&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Biologist, Archaeologist, Web Developer</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Michael&nbsp; Pointkowski&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Archaeologist</td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Holly Shelton&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Archaeologist, Geoarchaeologist, Grand River Institute </td>
              </tr>
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Josh Smith&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Paleontologist</td>
              </tr>             
              <tr style="text-align: center">
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Jessica Yaquinto&nbsp;&nbsp;</strong></td>
                <td style="text-align: left">Founder/Principal Investigator, Living Heritage Anthropology; Principal Investigator Ethnography and Applied Anthropology for DARG Ute Trails Projects</td>
              </tr>
            </tbody>
          </table>
          
          <h5>Technical Advisors</h5>
          
          <table width="400" border="0" align="center" cellpadding="1">
            <tbody>
              <tr style="text-align: left">
                <td width="200" height="40" style="color: #eb8f00; text-align: right;"><strong>Steven G. Baker&nbsp;&nbsp;</strong></td>
                <td width="400">Archaeologist, Program Director Uncompahgre Valley Ute Project, Centuries Research, Inc., Montrose, CO</td>
              </tr>
              <tr>
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>C. David Beers&nbsp;&nbsp;</strong></td>
                <td>Cultural Anthropologist, Independent Consultant, Farmington, NM</td>
              </tr>
              <tr>
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Betsy Chapoose&nbsp;&nbsp;</strong></td>
                <td>Director of Cultural Rights and Protection Department, Ute Indian Tribe of the Uintah &amp; Ouray Reservation, Ft. Duchesne, UT</td>
              </tr>
              <tr>
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Brock Chapoose&nbsp;&nbsp;</strong></td>
                <td>Cultural Rights and Protection Department, Ute Indian Tribe of the Uintah &amp; Ouray Reservation, Ft. Duchesne, UT</td>
              </tr>
              <tr>
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Julie Coleman&nbsp;&nbsp;</strong></td>
                <td>Archaeologist, San Juan Public Lands Center, BLM</td>
              </tr>
              <tr>
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Dan Haas&nbsp;&nbsp;</strong></td>
                <td>Archaeologist, Colorado State Office, BLM</td>
              </tr>
              <tr>
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Glade Hadden&nbsp;&nbsp;</strong></td>
                <td>Archaeologist, Uncompahgre Field Office, BLM</td>
              </tr>
              <tr>
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>James D. Keyser&nbsp;&nbsp;</strong></td>
                <td>Archaeologist, USDA-FS, Portland, OR</td>
              </tr>
              <tr>
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Terry G. Knight, Sr.&nbsp;&nbsp;</strong></td>
                <td>Cultural Resources NAGPRA Liaison, Ute Mountain Ute Tribe,Towaoc, CO</td>
              </tr>
              <tr>
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Aline LaForge&nbsp;&nbsp;</strong></td>
                <td>Archaeologist, Grand Junction Field Office, BLM	(Retired)</td>
              </tr>
              <tr>
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Michael D. Metcalf&nbsp;&nbsp;</strong></td>
                <td>Archaeologist, Metcalf Archaeological Consultants, Eagle, CO</td>
              </tr>
              <tr>
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Alden Naranjo&nbsp;&nbsp;</strong></td>
                <td>NAGPRA Coordinator, Southern Ute Indian Tribe</td>
              </tr>
              <tr>
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Cassandra J.&nbsp; Naranjo&nbsp;&nbsp;</strong></td>
                <td>NAGPRA Coordinator Apprentice, Southern Ute Culture Department</td>
              </tr>
              <tr>
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Carol Patterson&nbsp;&nbsp;</strong></td>
                <td>Archaeologist, Uncompahgre Field Office, BLM</td>
              </tr>
              <tr>
                <td height="40" style="color: #eb8f00; text-align: right;"><strong>Michael Selle&nbsp;&nbsp;</strong></td>
                <td>Archaeologist, White River Field Office, BLM</td>
              </tr>
            </tbody>
          </table>  
                        </div>                        
                    </div>                    
                </div>
                
            </section>
            
            
            <!-- Section 4 -->
            <section class="tm-section tm-section-partners" id="partners">

                <div class="tm-page-content-width">
                    <div class="tm-bg-black-translucent tm-content-box tm-flex-center">
                        <div class="tm-content-box-inner">
                            <h2 class="tm-section-title">Funding Partners</h2>
							<p style="font-size: 14px">DARG projects are funded through grants from the State Historical Fund, offices of the Colorado Bureau of Land Management, the U.S. Forest Service, and the National Park Service. Our private contributors include: EnCana Oil; EPCO, Inc; Gas USA, Inc.; Rhino Energy; Grand River Institute; and The Williams Companies, Inc. Additionally, DARG research associates regularly contribute significant pro bono hours working both on funded projects and organizational development.</p>
                            <p style="text-align: center"><a href="http://www.historycolorado.org/oahp/state-historical-fund" title="State Historical Fund" target="_blank"><img src="Image/Partners/History-colorado-logo.png" width="196" height="70" alt=""></a></p>
                            <p style="text-align: center"><a href="https://www.blm.gov/wo/st/en.html" title="Bureau of Land Management" target="_blank">
							<img src="Image/Partners/BLM.png" width="130" height="110" alt=""></a></p>
                            <p style="text-align: center"><a href="https://www.fs.fed.us/" title="U.S. Forest Service" target="_blank"><img src="Image/Partners/Forest Service.png" width="126" height="120" alt=""></a></p>
                            <p style="text-align: center"><a href="https://www.fs.fed.us/" title="National Park Service" target="_blank"><img src="Image/Partners/National Park Service.png" width="106" height="130" alt=""></a></p>
                            <h2 class="tm-section-title">Research Partners</h2>
                            <p style="font-size: 14px">DARG’s research program includes on-going collaborative partnerships with cultural representatives of the Ute Indian Tribe of the Uintah and Ouray Reservation, the Ute Mountain Ute Tribe, the Southern Ute Indian Tribe,  and archaeology and historic preservation programs of History Colorado.</p>
                            <p style="text-align: center"><a href="http://utetribe.com/" title="Ute Indian Tribe" target="_blank"><img src="Image/Partners/northern-ute.png" width="130" height="130" alt=""></a></p>
                            <p style="text-align: center"><a href="http://www.utemountainutetribe.com/" title="Ute Mountain Ute Tribe" target="_blank"><img src="Image/Partners/ute-mountain-ute.png" width="130" height="130" alt=""></a></p>
                            <p style="text-align: center"><a href="https://www.southernute-nsn.gov/" title="Southern Ute Indian Tribe" target="_blank"><img src="Image/Partners/suit-tribal-seal1-720x720.png" width="130" height="130" alt=""></a></p>
                     
                        </div>                        
                    </div> 
                </div>                
            </section>

            <!-- Section 5 -->
            <section class="tm-section tm-section-news" id="news">
                <div class="tm-page-content-width">
                    <h2 class="tm-section-title tm-section-title-big text-xs-center tm-text-black">News</h2>
                    
                         <div class="fbfeed">   
                            <!-- DARG FB Feed -->
                            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fdarg.colorado&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="350" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
                            
                            
                            <!-- CCPA FB Feed -->
                            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FColorado-Council-of-Professional-Archaeologists-CCPA-166322145779%2F%3Ffref%3Dnf&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="350" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>                         
                            
              				<!-- Grand River Institute FB Feed -->
                            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FGrandRiverInstitute%2F&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="350" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
                                                                                                                     
                         </div>
                    
					<p>&nbsp;</p>
                </div>                
            </section>

            <!-- Section 6 -->
            <section class="tm-section tm-section-educational" id="educational">
                <div class="tm-page-content-width">
                    <div class="tm-bg-black-translucent text-xs-left tm-textbox tm-2-col-textbox-2 tm-textbox-padding tm-textbox-padding-contact tm-content-box  tm-content-box-right">
                        <h2 class="tm-section-title">Educational</h2>
                        <p style="font-size: 20px;"><a href="educational.php#tabs-1">&diams; Obsidian Mapping</a></p>
                        <p style="font-size: 20px;"><a href="educational.php#tabs-3">&diams; Research Themes</a></p>
                        <p style="font-size: 20px"><a href="educational.php#tabs-4">&diams; Presentations</a></p>
						<p style="font-size: 20px"><a href="educational.php#tabs-5">&diams; Publications</a></p>
						<p style="font-size: 20px"><a href="educational.php#tabs-6">&diams; Gallery</a></p>
						<p style="font-size: 20px"><a href="educational.php#tabs-7">&diams; Databases (Public & Professional)</a></p>
                        
                    </div>
                </div>                
            </section>

        
        	<!-- Section 7 -->
            <section class="tm-section tm-section-contact" id="contact">

                <div class="tm-page-content-width">
                    <div class="tm-bg-black-translucent tm-content-box tm-flex-center">
                        <div class="tm-content-box-inner">
                            <h2 class="tm-section-title">Contact</h2>
                            <p class="Contact" style="font-size: 16px; text-align: left;">
                    Dominquez Archaeological Research Group (DARG)<br>
                    Mail: P.O. Box 3543, Grand Junction, CO 81502<br>
                    Phone: 970-245-7868<br>
                    Email: <a href="mailto:darg.colorado@gmail.com" target="_blank">darg.colorado@gmail.com</a></p>                  
                 
							<p>&nbsp;</p>
                       <!-- Paypal -->
                            <center>
								<p>All Donations Will Be Used For Matching Funds For Grants:</p>
                            <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
							<input type="hidden" name="cmd" value="_s-xclick">
							<input type="hidden" name="hosted_button_id" value="5Z9GEZCHHQZHQ">
							<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
							<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
							</form>
							</center>
                        </div>                        
                    </div> 
                </div>
                <div class="tm-bg-black-translucent tm-copyright-div">
                    <p class="tm-copyright-text">Dominquez Archaeological Research Group, Inc. is a 501(c)(3) non-profit corporation. • P.O. Box 3543 • Grand Junction, CO 81502 • Phone: 970-245-7868 • darg.colorado@gmail.com</p>
                </div>                
            </section>
            
        <!-- load JS files -->
        <script src="js/jquery-1.11.3.min.js"></script>         <!-- jQuery (https://jquery.com/download/) -->
        <script src="js/tether.min.js"></script>  <!-- Tether for Bootstrap (http://stackoverflow.com/questions/34567939/how-to-fix-the-error-error-bootstrap-tooltips-require-tether-http-github-h) -->
        <script src="js/bootstrap.min.js"></script>             <!-- Bootstrap js (v4-alpha.getbootstrap.com/) -->
        <script src="js/jquery.singlePageNav.min.js"></script>  <!-- Single page nav (https://github.com/ChrisWojcik/single-page-nav) -->
        
        <script>     
          
            // Check scroll position and add/remove background to navbar
            function checkScrollPosition() {
                
                if($(window).width() < 767) {
                    $(".tm-nav").removeClass("scroll");
                    return;
                }

                if($(window).scrollTop() > 50) {
                  $(".tm-nav").addClass("scroll");
              } else {        
                  $(".tm-nav").removeClass("scroll");
              }
            }

            $(document).ready(function () {   
                // Single page nav
                $('.tm-nav').singlePageNav({
                    offset: 57,
                    filter: ':not(.external)',
                    updateHash: true        
                });

                checkScrollPosition();

                // navbar
                $('.navbar-toggle').click(function(){
                    $('.main-menu').toggleClass('show');
                });

                $('.main-menu a').click(function(){
                    $('.main-menu').removeClass('show');
                });
            });

            $(window).on("scroll", function() {
                checkScrollPosition();    
            });

            $('#tmNavbar a').click(function(){
                $('#tmNavbar').collapse('hide');
            });

        </script>
        
                                           
		</div>
</body>
</html>